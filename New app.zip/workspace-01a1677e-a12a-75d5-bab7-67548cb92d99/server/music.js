import path from 'node:path';
import { getSecret } from './secrets.js';
import { getSettings } from './store.js';
import { AppError } from './errors.js';
import { asString, downloadToFile, fetchChecked, sleep } from './utils.js';

export async function generateMusic({ input, creative, destination, onProgress = () => {} }) {
  const apiKey = process.env.MUSICGPT_API_KEY || getSecret('musicgptApiKey');
  if (!apiKey) {
    throw new AppError(
      'Automatic music ke liye MusicGPT API key chahiye. Ya Suno/MusicGPT website se audio bana kar Audio Import use karein.',
      412,
      'MUSIC_API_REQUIRED',
    );
  }
  const settings = getSettings();
  const body = await fetchChecked('https://api.musicgpt.com/api/public/v2/MusicAI', {
    method: 'POST',
    headers: { Authorization: apiKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: asString(input.topic, 950),
      music_style: creative.style,
      lyrics: input.instrumental ? '' : creative.lyrics,
      title: creative.songTitle,
      make_instrumental: Boolean(input.instrumental),
      vocal_only: false,
      gender: input.instrumental ? '' : (input.vocalGender || 'neutral'),
      voice_id: '',
      generate_album_cover: false,
      lyrics_timestamps: false,
      model: settings.musicModel || 'v7',
    }),
  }, 'MusicGPT');

  if (body?.success === false || !body?.task_id) {
    throw new AppError(`MusicGPT ne generation start nahi ki: ${body?.message || body?.error_code || 'unknown response'}`, 400, 'MUSIC_GENERATION_REJECTED');
  }
  const taskId = body.task_id;
  const etaSeconds = Math.max(30, Number(body.eta) || 180);
  const started = Date.now();
  const deadline = started + 35 * 60 * 1000;

  while (Date.now() < deadline) {
    await sleep(8_000);
    const query = new URLSearchParams({ conversionType: 'MUSIC_AI', task_id: taskId });
    const statusBody = await fetchChecked(`https://api.musicgpt.com/api/public/v1/byId?${query}`, {
      headers: { Authorization: apiKey },
    }, 'MusicGPT status');
    const conversion = statusBody?.conversion || statusBody?.conversions?.[0] || statusBody;
    const status = String(conversion?.status || '').toUpperCase();
    if (['ERROR', 'FAILED', 'CANCELLED'].includes(status)) {
      throw new AppError(`Music generation fail ho gayi: ${conversion?.status_msg || status}`, 502, 'MUSIC_GENERATION_FAILED');
    }
    if (status === 'COMPLETED' && conversion?.audio_url) {
      onProgress(92);
      const extension = path.extname(new URL(conversion.audio_url).pathname).toLowerCase();
      const audioPath = `${destination}${['.mp3', '.wav', '.m4a', '.aac', '.ogg'].includes(extension) ? extension : '.mp3'}`;
      await downloadToFile(conversion.audio_url, audioPath);
      return { audioPath, providerTaskId: taskId, providerCost: conversion?.conversion_cost ?? body?.credit_estimate ?? null };
    }
    const elapsed = (Date.now() - started) / 1000;
    onProgress(Math.min(88, Math.round((elapsed / etaSeconds) * 85)));
  }
  throw new AppError('Music generation 35 minute mein complete nahi hui. MusicGPT dashboard check karke retry karein.', 504, 'MUSIC_GENERATION_TIMEOUT');
}
