from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'android' / 'app' / 'src' / 'main' / 'res'
LIME = '#C6F56F'
DARK = '#0B0D0F'
INK = '#11150D'


def waveform(draw, box, width):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    points = [(0.10, .55), (.23, .55), (.32, .25), (.45, .79), (.57, .34), (.69, .63), (.77, .48), (.90, .48)]
    xy = [(x0 + px * w, y0 + py * h) for px, py in points]
    draw.line(xy, fill=INK, width=max(2, int(width)), joint='curve')
    radius = width / 2
    for x, y in (xy[0], xy[-1]):
        draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=INK)


def icon(size, kind='standard'):
    scale = 4
    s = size * scale
    image = Image.new('RGBA', (s, s), (0, 0, 0, 0) if kind == 'adaptive' else DARK)
    draw = ImageDraw.Draw(image)
    if kind == 'adaptive':
        pad = int(s * .19)
        radius = int(s * .15)
    else:
        pad = int(s * .055)
        radius = int(s * .20)
    draw.rounded_rectangle((pad, pad, s-pad, s-pad), radius=radius, fill=LIME)
    waveform(draw, (pad, pad, s-pad, s-pad), s * .045)
    if kind == 'round':
        mask = Image.new('L', (s, s), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, s, s), fill=255)
        image.putalpha(mask)
    return image.resize((size, size), Image.Resampling.LANCZOS)


for density, size in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    folder = RES / f'mipmap-{density}'
    icon(size).save(folder / 'ic_launcher.png')
    icon(size, 'round').save(folder / 'ic_launcher_round.png')
    icon(size * 3, 'adaptive').save(folder / 'ic_launcher_foreground.png')

for path in RES.glob('drawable*/splash.png'):
    with Image.open(path) as existing:
        width, height = existing.size
    scale = 2
    image = Image.new('RGB', (width*scale, height*scale), DARK)
    draw = ImageDraw.Draw(image)
    side = int(min(width, height) * .28) * scale
    x0 = (width*scale-side)//2
    y0 = (height*scale-side)//2
    draw.rounded_rectangle((x0, y0, x0+side, y0+side), radius=int(side*.23), fill=LIME)
    waveform(draw, (x0, y0, x0+side, y0+side), side*.055)
    image.resize((width, height), Image.Resampling.LANCZOS).save(path)

print('SurFlow launcher icons and splash screens generated.')
