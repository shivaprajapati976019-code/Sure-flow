import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { createDemoAudio } from '../server/render.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';
const artifactDir = path.resolve('artifacts/manual-flow');
fs.mkdirSync(artifactDir, { recursive: true });
const audioPath = await createDemoAudio(artifactDir);
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
page.on('pageerror', (error) => errors.push(`page: ${error.message}`));
await page.addInitScript(() => localStorage.removeItem('surflow_draft'));

try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /Naya song/i }).first().click();
  await page.locator('.idea-input').fill('रात में शहर की रोशनी और एक अधूरा संदेश');
  await page.getByRole('button', { name: /Aage badho/i }).click();
  await page.getByRole('button', { name: /Manually likhunga/i }).click();
  await page.locator('.creative-editor input').fill('रात का सिग्नल');
  await page.locator('.lyrics-input').fill('[Verse]\nशहर की बत्तियाँ धीमी हैं\nएक संदेश है, बात अधूरी\n\n[Chorus]\nरात का सिग्नल मिल जाए तो\nतेरी आवाज़ घर आ जाए');
  await page.getByRole('button', { name: /Audio import/i }).click();
  await page.locator('input[type="file"][accept*="audio/mpeg"]').setInputFiles(audioPath);
  await page.locator('.upload-zone.has-file').waitFor({ timeout: 30_000 });
  await page.getByRole('button', { name: /Aage badho/i }).click();
  await page.getByRole('button', { name: /Pulse wave/i }).click();
  await page.getByRole('button', { name: /Aage badho/i }).click();

  const autoPublish = page.getByRole('switch', { name: 'Automatic YouTube upload' });
  if (await autoPublish.getAttribute('aria-checked') === 'true') await autoPublish.click();
  await page.locator('.rights-check').click();
  await page.getByRole('button', { name: /Video ready karein/i }).click();
  await page.waitForURL(/#\/jobs\//, { timeout: 30_000 });
  await page.getByText('Master ready hai').waitFor({ timeout: 90_000 });

  const video = page.locator('video.final-video');
  await video.waitFor({ timeout: 15_000 });
  await page.waitForFunction(() => {
    const element = document.querySelector('video.final-video');
    return element && element.readyState >= 1 && element.videoWidth > 0;
  }, null, { timeout: 20_000 });
  const media = await video.evaluate((element) => ({
    duration: element.duration,
    width: element.videoWidth,
    height: element.videoHeight,
    src: element.currentSrc,
  }));
  const response = await page.request.head(media.src);
  const result = {
    title: await page.locator('.job-title-row h1').textContent(),
    status: 'ready',
    media: { duration: media.duration, width: media.width, height: media.height },
    videoHeadStatus: response.status(),
    errors,
  };
  await page.screenshot({ path: path.join(artifactDir, 'ready-job.png'), fullPage: true });
  console.log(JSON.stringify(result, null, 2));
  if (result.title !== 'रात का सिग्नल' || response.status() !== 200 || media.width !== 1280 || media.height !== 720 || errors.length) process.exitCode = 1;
} finally {
  await browser.close();
}
