import crypto from 'node:crypto';
import { APP_ACCESS_CODE } from './config.js';

const sessions = new Map();
const SESSION_TTL = 30 * 24 * 60 * 60 * 1000;

function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

export function createSession(code) {
  if (APP_ACCESS_CODE && !safeEqual(code || '', APP_ACCESS_CODE)) return null;
  const token = crypto.randomBytes(32).toString('base64url');
  sessions.set(token, Date.now() + SESSION_TTL);
  return token;
}

export function requireAuth(req, res, next) {
  if (!APP_ACCESS_CODE) return next();
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const expiry = sessions.get(token);
  if (!expiry || expiry < Date.now()) {
    if (token) sessions.delete(token);
    return res.status(401).json({ error: 'Session expire ho gaya. Access code se login karein.', code: 'UNAUTHORIZED' });
  }
  sessions.set(token, Date.now() + SESSION_TTL);
  next();
}

export const authRequired = Boolean(APP_ACCESS_CODE);
