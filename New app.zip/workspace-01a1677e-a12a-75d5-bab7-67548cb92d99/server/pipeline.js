import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { MEDIA_DIR, UPLOAD_DIR, MAX_DAILY_UPLOADS } from './config.js';
import { getJob, getSettings, getYoutube, listJobs, patchJob, putJob } from './store.js';
import { generateCreative, generateMetadata } from './ai.js';
import { generateMusic } from './music.js';
import { createDemoAudio, renderVideo } from './render.js';
import { uploadToYoutube } from './youtube.js';
import { AppError } from './errors.js';
import { asBool, asString, sleep, toPublicJob } from './utils.js';

const active = new Set();
const STAGES = [
  ['writing', 'Lyrics + style'],
  ['music', 'Music'],
  ['video', 'Visualizer video'],
  ['metadata', 'Title + description'],
  ['publish', 'YouTube'],
];
const newStages = () => STAGES.map(([id, label]) => ({ id, label, status: 'pending' }));

function uploadPath(id, kind) {
  if (!id) return null;
  const clean = path.basename(String(id));
  const full = path.resolve(UPLOAD_DIR, clean);
  if (path.dirname(full) !== path.resolve(UPLOAD_DIR) || !fs.existsSync(full)) {
    throw new AppError(`${kind === 'audio' ? 'Audio' : 'Video'} upload expire ho gaya. File dobara upload karein.`, 412, 'UPLOAD_MISSING');
  }
  return full;
}

export function validateJobPayload(body) {
  const creative = body.creative ? {
    songTitle: asString(body.creative.songTitle, 90).replace(/[<>]/g, ''),
    lyrics: asString(body.creative.lyrics, 2900),
    style: asString(body.creative.style, 900),
    negativeTags: asString(body.creative.negativeTags, 500),
  } : null;
  const topic = asString(body.input?.topic, 600);
  if (topic.length < 3) throw new AppError('Song ka idea kam se kam 3 characters mein likhein.', 400, 'TOPIC_REQUIRED');
  if (!body.rightsConfirmed) throw new AppError('Publish karne se pehle content rights ki confirmation zaroori hai.', 400, 'RIGHTS_CONFIRMATION_REQUIRED');
  const musicSource = body.options?.musicSource === 'upload' ? 'upload' : 'auto';
  const videoSource = body.options?.videoSource === 'external' ? 'external' : 'builtin';
  const audioUploadId = path.basename(asString(body.options?.audioUploadId, 120));
  const videoUploadId = path.basename(asString(body.options?.videoUploadId, 120));
  if (musicSource === 'upload' && !audioUploadId && videoSource !== 'external') {
    throw new AppError('Audio file upload karein ya AI Music Generate select karein.', 400, 'AUDIO_REQUIRED');
  }
  if (videoSource === 'external' && !videoUploadId) {
    throw new AppError('External visualizer se banaya MP4 upload karein.', 400, 'EXTERNAL_VIDEO_REQUIRED');
  }
  const privacy = ['public', 'private', 'unlisted'].includes(body.options?.privacy) ? body.options.privacy : 'private';
  let scheduleAt = null;
  if (body.options?.scheduleAt) {
    const date = new Date(body.options.scheduleAt);
    if (Number.isNaN(date.getTime()) || date.getTime() <= Date.now() + 60_000) {
      throw new AppError('Schedule time future mein select karein.', 400, 'INVALID_SCHEDULE');
    }
    scheduleAt = date.toISOString();
  }
  return {
    input: {
      topic,
      language: asString(body.input?.language || 'Hinglish', 60),
      genre: asString(body.input?.genre || 'Bollywood pop', 100),
      mood: asString(body.input?.mood || 'Emotional', 100),
      details: asString(body.input?.details, 800),
      duration: Math.max(30, Math.min(600, Number(body.input?.duration) || 180)),
      vocalGender: ['male', 'female', 'neutral'].includes(body.input?.vocalGender) ? body.input.vocalGender : 'neutral',
      instrumental: asBool(body.input?.instrumental),
    },
    creative,
    metadata: body.metadata ? {
      title: asString(body.metadata.title, 100).replace(/[<>]/g, ''),
      description: asString(body.metadata.description, 5000).replace(/[<>]/g, ''),
      tags: Array.isArray(body.metadata.tags) ? body.metadata.tags.map((tag) => asString(tag, 60)).filter(Boolean).slice(0, 15) : [],
      hashtags: Array.isArray(body.metadata.hashtags) ? body.metadata.hashtags.map((tag) => asString(tag, 40)).slice(0, 5) : [],
    } : null,
    options: {
      musicSource,
      videoSource,
      audioUploadId,
      videoUploadId,
      autoPublish: asBool(body.options?.autoPublish, true),
      privacy,
      scheduleAt,
      visualTemplate: ['nebula', 'pulse', 'bars'].includes(body.options?.visualTemplate) ? body.options.visualTemplate : 'nebula',
      visualPalette: ['lime', 'violet', 'sunset', 'ocean'].includes(body.options?.visualPalette) ? body.options.visualPalette : 'lime',
      madeForKids: asBool(body.options?.madeForKids),
      containsSyntheticMedia: asBool(body.options?.containsSyntheticMedia, true),
    },
  };
}

export function createJob(body) {
  const data = validateJobPayload(body);
  const now = new Date().toISOString();
  const job = {
    id: crypto.randomUUID(),
    demo: false,
    title: data.creative?.songTitle || data.input.topic.slice(0, 70),
    ...data,
    status: 'queued',
    progress: 0,
    currentStage: 'writing',
    stages: newStages(),
    logs: [{ at: now, message: 'Release queue mein add hua.' }],
    error: null,
    createdAt: now,
    updatedAt: now,
  };
  putJob(job);
  setImmediate(() => runJob(job.id));
  return toPublicJob(job);
}

export function createDemoJob(overrides = {}) {
  const now = new Date().toISOString();
  const settings = getSettings();
  const job = {
    id: crypto.randomUUID(),
    demo: true,
    title: 'Raat Ka Signal',
    input: { topic: 'Shehar ki raat aur ek adhoora message', language: 'Hinglish', genre: 'Ambient pop', mood: 'Dreamy', duration: 12, vocalGender: 'neutral', instrumental: false, details: '' },
    creative: {
      songTitle: 'Raat Ka Signal',
      lyrics: '[Verse]\nShehar ki battiyan dheemi hain\nEk message hai, baat adhoori\n\n[Chorus]\nRaat ka signal mil jaaye toh\nTeri awaaz ghar aa jaaye',
      style: 'Dreamy ambient pop, 82 BPM, warm electric piano, soft pads, subtle downtempo beat, intimate vocal, wide spacious mix.',
      negativeTags: 'harsh distortion, clipped vocals',
    },
    metadata: null,
    options: {
      musicSource: 'demo', videoSource: 'builtin', autoPublish: false,
      privacy: 'private', scheduleAt: null,
      visualTemplate: overrides.visualTemplate || settings.visualTemplate,
      visualPalette: overrides.visualPalette || settings.visualPalette,
      madeForKids: false, containsSyntheticMedia: true,
    },
    status: 'queued', progress: 0, currentStage: 'writing', stages: newStages(),
    logs: [{ at: now, message: 'Local demo shuru hua—koi paid AI call ya YouTube upload nahi hoga.' }],
    error: null, createdAt: now, updatedAt: now,
  };
  putJob(job);
  setImmediate(() => runJob(job.id));
  return toPublicJob(job);
}

function setStage(job, id, status, progress = job.progress) {
  job.currentStage = id;
  job.progress = Math.max(job.progress, Math.min(100, Math.round(progress)));
  job.stages = job.stages.map((stage) => stage.id === id ? { ...stage, status } : stage);
  job.updatedAt = new Date().toISOString();
  putJob(job);
}

function log(job, message) {
  job.logs = [...(job.logs || []), { at: new Date().toISOString(), message }].slice(-30);
  putJob(job);
}

function checkDailyLimit() {
  const limit = Math.min(MAX_DAILY_UPLOADS, getSettings().dailyLimit || 5);
  const today = new Date().toISOString().slice(0, 10);
  const count = listJobs().filter((job) => job.uploadedAt?.startsWith(today)).length;
  if (count >= limit) throw new AppError(`Aaj ki ${limit} uploads ki safety limit poori ho gayi. Settings se limit badhayein ya kal try karein.`, 429, 'DAILY_UPLOAD_LIMIT');
}

async function publishExisting(id) {
  const job = getJob(id);
  if (!job?.videoPath || !fs.existsSync(job.videoPath)) throw new AppError('Pehle video render complete karein.', 412, 'VIDEO_MISSING');
  if (!getYoutube().connected) {
    patchJob(id, { status: 'action_required', action: 'connect_youtube', currentStage: 'publish', progress: 90 });
    throw new AppError('YouTube account connect karein, phir publish dobara shuru karein.', 412, 'YOUTUBE_NOT_CONNECTED');
  }
  checkDailyLimit();
  setStage(job, 'publish', 'active', 90);
  job.status = 'uploading';
  job.error = null;
  log(job, 'YouTube resumable upload shuru hua.');
  try {
    const result = await uploadToYoutube({
      videoPath: job.videoPath,
      metadata: job.metadata,
      privacy: job.options.privacy,
      scheduleAt: job.options.scheduleAt,
      madeForKids: job.options.madeForKids,
      containsSyntheticMedia: job.options.containsSyntheticMedia,
      onProgress: (value) => patchJob(id, { progress: 90 + Math.round(value * 0.09) }),
    });
    job.status = result.publishAt ? 'scheduled' : 'published';
    job.progress = 100;
    job.youtube = result;
    job.uploadedAt = new Date().toISOString();
    setStage(job, 'publish', 'completed', 100);
    log(job, result.publishAt ? `YouTube par ${result.publishAt} ke liye scheduled.` : 'YouTube upload complete.');
    return toPublicJob(job);
  } catch (error) {
    job.status = 'action_required';
    job.action = error.code === 'DAILY_UPLOAD_LIMIT' ? 'daily_limit' : 'retry_upload';
    job.error = { code: error.code || 'YOUTUBE_UPLOAD_FAILED', message: error.message };
    setStage(job, 'publish', 'error', job.progress);
    throw error;
  }
}

export async function runJob(id) {
  if (active.has(id)) return;
  const job = getJob(id);
  if (!job) return;
  active.add(id);
  try {
    job.status = job.demo ? 'rendering_demo' : 'running';
    job.error = null;
    job.action = null;
    putJob(job);
    const jobDir = path.join(MEDIA_DIR, id);
    fs.mkdirSync(jobDir, { recursive: true, mode: 0o700 });

    setStage(job, 'writing', 'active', Math.max(job.progress, 3));
    if (!job.creative) {
      log(job, 'AI original lyrics aur music style likh raha hai.');
      job.creative = await generateCreative(job.input);
      job.title = job.creative.songTitle;
      putJob(job);
    }
    setStage(job, 'writing', 'completed', 20);

    setStage(job, 'music', 'active', 21);
    if (!job.audioPath || !fs.existsSync(job.audioPath)) {
      if (job.demo) {
        job.audioPath = await createDemoAudio(jobDir);
        log(job, '12-second original demo instrumental ready.');
      } else if (job.options.musicSource === 'upload') {
        const source = uploadPath(job.options.audioUploadId, 'audio');
        if (source) {
          const extension = path.extname(source).toLowerCase() || '.mp3';
          job.audioPath = path.join(jobDir, `audio${extension}`);
          fs.copyFileSync(source, job.audioPath);
          log(job, 'Imported audio pipeline mein add hua.');
        }
      } else {
        log(job, 'MusicGPT original audio generate kar raha hai.');
        const result = await generateMusic({
          input: job.input,
          creative: job.creative,
          destination: path.join(jobDir, 'audio'),
          onProgress: (value) => patchJob(id, { progress: 22 + Math.round(value * 0.27) }),
        });
        job.audioPath = result.audioPath;
        job.music = { provider: 'MusicGPT', taskId: result.providerTaskId, cost: result.providerCost };
        log(job, 'AI music generate ho kar server par save hua.');
      }
    }
    if (!job.audioPath && job.options.videoSource !== 'external') throw new AppError('Audio file nahi mili.', 412, 'AUDIO_REQUIRED');
    putJob(job);
    setStage(job, 'music', 'completed', 50);

    setStage(job, 'video', 'active', 51);
    if (!job.videoPath || !fs.existsSync(job.videoPath)) {
      if (job.options.videoSource === 'external') {
        const source = uploadPath(job.options.videoUploadId, 'video');
        job.videoPath = path.join(jobDir, 'video.mp4');
        fs.copyFileSync(source, job.videoPath);
        log(job, 'External visualizer video pipeline mein add hua.');
      } else {
        log(job, `${job.options.visualTemplate} visualizer render ho raha hai.`);
        job.videoPath = await renderVideo({
          audioPath: job.audioPath,
          jobDir,
          title: job.creative.songTitle,
          artist: getSettings().artistName || (job.demo ? 'SurFlow demo' : 'Original release'),
          template: job.options.visualTemplate,
          paletteName: job.options.visualPalette,
          onProgress: (value) => patchJob(id, { progress: 51 + Math.round(value * 0.27) }),
        });
        log(job, 'HD MP4 visualizer ready.');
      }
    }
    putJob(job);
    setStage(job, 'video', 'completed', 80);

    setStage(job, 'metadata', 'active', 82);
    if (!job.metadata) {
      if (job.demo) {
        job.metadata = {
          title: 'Raat Ka Signal | Original Ambient Pop',
          description: 'Shehar ki khamosh raat aur ek adhoora message par ek original ambient-pop idea.\n\nYeh SurFlow ka locally generated visualizer demo hai. Music, visualizer aur release workflow ko test karne ke liye banaya gaya hai.\n\n#AmbientPop #OriginalMusic #Hinglish',
          tags: ['ambient pop', 'hinglish music', 'original song', 'surflow demo'],
          hashtags: ['#AmbientPop', '#OriginalMusic', '#Hinglish'],
        };
      } else {
        log(job, 'AI YouTube title, description aur tags likh raha hai.');
        job.metadata = await generateMetadata(job.input, job.creative);
      }
      putJob(job);
    }
    setStage(job, 'metadata', 'completed', 88);

    if (!job.options.autoPublish || job.demo) {
      setStage(job, 'publish', 'skipped', 100);
      job.status = 'ready';
      job.progress = 100;
      job.title = job.metadata.title;
      log(job, job.demo ? 'Demo ready. Isse YouTube par upload nahi kiya gaya.' : 'Video review/download ke liye ready. Auto-publish off hai.');
      putJob(job);
      return;
    }
    await publishExisting(id);
  } catch (error) {
    const current = getJob(id);
    if (!current) return;
    if (current.status === 'action_required' && current.currentStage === 'publish') return;
    current.status = ['YOUTUBE_NOT_CONNECTED', 'DAILY_UPLOAD_LIMIT'].includes(error.code) ? 'action_required' : 'failed';
    current.action = error.code === 'YOUTUBE_NOT_CONNECTED' ? 'connect_youtube' : null;
    current.error = { code: error.code || 'PIPELINE_FAILED', message: error.message || 'Pipeline fail ho gayi.' };
    const stage = current.stages.find((item) => item.id === current.currentStage);
    if (stage) stage.status = 'error';
    log(current, current.error.message);
    putJob(current);
  } finally {
    active.delete(id);
  }
}

export async function publishJob(id, overrides = {}) {
  const job = getJob(id);
  if (!job) throw new AppError('Release nahi mila.', 404, 'JOB_NOT_FOUND');
  if (job.demo) throw new AppError('Demo sirf local preview ke liye hai. Real release create karein.', 400, 'DEMO_CANNOT_PUBLISH');
  if (overrides.metadata) job.metadata = { ...job.metadata, ...overrides.metadata };
  if (overrides.privacy && ['public', 'private', 'unlisted'].includes(overrides.privacy)) job.options.privacy = overrides.privacy;
  if (overrides.scheduleAt !== undefined) job.options.scheduleAt = overrides.scheduleAt || null;
  job.options.autoPublish = true;
  putJob(job);
  return publishExisting(id);
}

export function retryJob(id) {
  const job = getJob(id);
  if (!job) throw new AppError('Release nahi mila.', 404, 'JOB_NOT_FOUND');
  if (active.has(id)) return toPublicJob(job);
  job.status = 'queued';
  job.error = null;
  putJob(job);
  setImmediate(() => runJob(id));
  return toPublicJob(job);
}

export function publicJob(id) {
  return toPublicJob(getJob(id));
}

export function publicJobs() {
  return listJobs().map(toPublicJob);
}

export function recoverInterruptedJobs() {
  for (const job of listJobs()) {
    if (['running', 'rendering_demo', 'uploading', 'queued'].includes(job.status)) {
      job.status = 'failed';
      job.error = { code: 'SERVER_INTERRUPTED', message: 'Server restart ke kaaran workflow ruka. Retry dabayein; saved files dobara use hongi.' };
      putJob(job);
    }
  }
}
