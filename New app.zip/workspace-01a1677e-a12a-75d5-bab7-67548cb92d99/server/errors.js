export class AppError extends Error {
  constructor(message, status = 400, code = 'BAD_REQUEST', details = undefined) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

export function publicError(error) {
  if (error instanceof AppError) {
    return { error: error.message, code: error.code, details: error.details };
  }
  if (error?.name === 'AbortError' || error?.name === 'TimeoutError') {
    return { error: 'External service ne time par response nahi diya. Phir se try karein.', code: 'UPSTREAM_TIMEOUT' };
  }
  return { error: 'Kuch gadbad ho gayi. Server logs check karein.', code: 'INTERNAL_ERROR' };
}
