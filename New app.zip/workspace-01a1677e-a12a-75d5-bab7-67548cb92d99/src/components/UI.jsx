import React from 'react';
import { ArrowUpRight, AudioLines, Check, ChevronRight, CircleAlert, Clock3, LoaderCircle, Plus, Sparkles } from 'lucide-react';
import { PALETTES, STATUS_LABELS } from '../data.js';
import { classNames, formatDate } from '../utils.js';

export function Logo({ compact = false }) {
  return <div className={classNames('brand', compact && 'brand-compact')}>
    <span className="brand-mark" aria-hidden="true">
      <svg viewBox="0 0 40 40" fill="none"><path d="M7 22h4l3-11 5 21 5-17 4 11 2-5h4" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
    </span>
    {!compact && <span className="brand-word">surflow<span className="brand-dot">.</span></span>}
  </div>;
}

export function StatusPill({ status }) {
  const tone = ['published', 'ready'].includes(status) ? 'success' : status === 'scheduled' ? 'violet' : ['failed', 'action_required'].includes(status) ? 'warning' : 'active';
  return <span className={classNames('status-pill', `status-${tone}`)}><span className="status-dot" />{STATUS_LABELS[status] || status}</span>;
}

export function Toggle({ checked, onChange, label, description, disabled = false }) {
  return <label className={classNames('toggle-row', disabled && 'is-disabled')}>
    {(label || description) && <span className="toggle-copy"><strong>{label}</strong>{description && <small>{description}</small>}</span>}
    <button type="button" role="switch" aria-checked={checked} aria-label={label || 'Toggle'} disabled={disabled} className={classNames('toggle', checked && 'is-on')} onClick={() => onChange(!checked)}><span /></button>
  </label>;
}

export function Spinner({ size = 18 }) {
  return <LoaderCircle size={size} className="spin" aria-label="Loading" />;
}

export function SectionTitle({ eyebrow, title, description, action }) {
  return <div className="section-title"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h2>{title}</h2>{description && <p>{description}</p>}</div>{action}</div>;
}

export function JobArt({ job, large = false }) {
  const palette = PALETTES[job?.options?.visualPalette] || PALETTES.lime;
  return <div className={classNames('job-art', large && 'job-art-large')} style={{ '--art-a': palette.first, '--art-b': palette.second, '--art-bg': palette.bg1 }}>
    <span className="art-orb" /><span className="art-grid" />
    <div className="mini-wave" aria-hidden="true">{Array.from({ length: 17 }, (_, index) => <i key={index} style={{ height: `${18 + ((index * 19) % 50)}%` }} />)}</div>
    {large && <AudioLines size={34} />}
  </div>;
}

export function JobCard({ job, onClick }) {
  const active = ['queued', 'running', 'rendering_demo', 'uploading'].includes(job.status);
  return <button className="job-card" onClick={onClick}>
    <JobArt job={job} />
    <div className="job-card-main">
      <div className="job-card-top"><StatusPill status={job.status} />{job.demo && <span className="demo-tag">DEMO</span>}<time>{formatDate(job.createdAt)}</time></div>
      <h3>{job.title || job.input?.topic}</h3>
      <p>{job.input?.genre} <span>•</span> {job.input?.language}</p>
      {active && <div className="job-progress"><div><i style={{ width: `${job.progress || 0}%` }} /></div><span>{job.progress || 0}%</span></div>}
      {job.status === 'action_required' && <span className="job-action"><CircleAlert size={14} />{job.action === 'connect_youtube' ? 'YouTube connect karein' : 'Retry / review karein'}</span>}
    </div>
    <ChevronRight className="job-chevron" size={20} />
  </button>;
}

export function EmptyState({ onCreate, onDemo }) {
  return <div className="empty-state">
    <div className="empty-icon"><Sparkles size={28} /></div>
    <h3>Aapki release library abhi khaali hai</h3>
    <p>Ek idea dijiye—SurFlow lyrics se video tak ka kaam sambhalega.</p>
    <div className="button-row"><button className="btn btn-primary" onClick={onCreate}><Plus size={17} />Naya song</button><button className="btn btn-ghost" onClick={onDemo}>Free demo banayein</button></div>
  </div>;
}

export function Stepper({ steps, current }) {
  return <div className="stepper">{steps.map((step, index) => {
    const number = index + 1;
    const done = number < current;
    return <React.Fragment key={step}>
      <div className={classNames('stepper-item', number === current && 'current', done && 'done')}><span>{done ? <Check size={14} /> : number}</span><small>{step}</small></div>
      {index < steps.length - 1 && <i className={classNames('stepper-line', done && 'done')} />}
    </React.Fragment>;
  })}</div>;
}

export function InlineNotice({ tone = 'info', title, children, action }) {
  return <div className={classNames('notice', `notice-${tone}`)}><CircleAlert size={19} /><div><strong>{title}</strong>{children && <p>{children}</p>}</div>{action}</div>;
}

export function SetupItem({ done, title, description, onClick }) {
  return <button className="setup-item" onClick={onClick}><span className={classNames('setup-check', done && 'done')}>{done ? <Check size={15} /> : <Clock3 size={15} />}</span><span><strong>{title}</strong><small>{description}</small></span><ArrowUpRight size={16} /></button>;
}
