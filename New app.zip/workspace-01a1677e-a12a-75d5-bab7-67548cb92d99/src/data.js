export const LANGUAGES = ['Hinglish', 'Hindi', 'Punjabi', 'English', 'Hindi (Devanagari)', 'Tamil', 'Telugu', 'Bengali'];
export const GENRES = ['Bollywood pop', 'Lo-fi', 'Punjabi pop', 'Romantic ballad', 'Hip-hop', 'EDM', 'Acoustic', 'Devotional', 'Indie pop', 'Sad song'];
export const MOODS = ['Romantic', 'Emotional', 'Dreamy', 'Energetic', 'Heartbreak', 'Happy', 'Motivational', 'Chill', 'Spiritual', 'Dark'];
export const IDEAS = [
  'Shehar ki raat mein kisi ko yaad karna',
  'Monsoon mein pehli mulaaqat',
  'Apne sapno ko lekar nikal padna',
  'Dosti, chai aur purani galliyan',
];
export const PALETTES = {
  lime: { name: 'Lime glow', first: '#c6f56f', second: '#8a6cff', bg0: '#0a0d0b', bg1: '#17251b' },
  violet: { name: 'Violet haze', first: '#b79cff', second: '#ff7ac8', bg0: '#0d0a14', bg1: '#25153b' },
  sunset: { name: 'Sunset', first: '#ffb65c', second: '#ff667d', bg0: '#140c09', bg1: '#351a16' },
  ocean: { name: 'Deep ocean', first: '#62e7f2', second: '#5478ff', bg0: '#071014', bg1: '#0b2933' },
};
export const STATUS_LABELS = {
  queued: 'Queue mein', running: 'Ban raha hai', rendering_demo: 'Demo render', uploading: 'Upload ho raha hai',
  action_required: 'Aapki action chahiye', failed: 'Ruk gaya', ready: 'Ready', published: 'Published', scheduled: 'Scheduled',
};
export const ACTIVE_STATUSES = ['queued', 'running', 'rendering_demo', 'uploading'];
