import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeCreative, normalizeMetadata } from '../server/ai.js';
import { validateJobPayload } from '../server/pipeline.js';
import { toPublicJob } from '../server/utils.js';

test('metadata is YouTube-safe and title is capped', () => {
  const result = normalizeMetadata({ title: `<${'A'.repeat(140)}>`, description: 'Hello <world>', tags: ['pop', 'hindi', 'pop'], hashtags: ['Original Music'] });
  assert.equal(result.title.length, 100);
  assert.equal(result.title.includes('<'), false);
  assert.equal(result.description, 'Hello world');
  assert.deepEqual(result.tags, ['pop', 'hindi']);
  assert.deepEqual(result.hashtags, ['#OriginalMusic']);
});

test('creative output respects MusicGPT-safe lengths', () => {
  const result = normalizeCreative({ songTitle: 'Test', lyrics: 'line\n'.repeat(1500), style: 'x'.repeat(1500) }, {});
  assert.ok(result.lyrics.length <= 2900);
  assert.ok(result.style.length <= 900);
  assert.equal(result.songTitle, 'Test');
});

test('creative output requires lyrics for vocal songs', () => {
  assert.throws(() => normalizeCreative({ lyrics: '', style: 'pop' }, {}), /lyrics/);
});

test('job validation requires rights confirmation', () => {
  assert.throws(() => validateJobPayload({ input: { topic: 'Test song' }, rightsConfirmed: false }), /rights/);
});

test('manual audio workflow validates without AI music', () => {
  const value = validateJobPayload({
    input: { topic: 'Imported song', language: 'Hinglish' },
    creative: { songTitle: 'Imported', lyrics: 'La la', style: 'pop' },
    options: { musicSource: 'upload', audioUploadId: 'abc.mp3', autoPublish: false },
    rightsConfirmed: true,
  });
  assert.equal(value.options.musicSource, 'upload');
  assert.equal(value.options.audioUploadId, 'abc.mp3');
  assert.equal(value.options.autoPublish, false);
});

test('public job never exposes local media paths', () => {
  const value = toPublicJob({ id: 'abc', audioPath: '/private/song.mp3', videoPath: '/private/video.mp4', status: 'ready' });
  assert.equal(value.audioPath, undefined);
  assert.equal(value.videoPath, undefined);
  assert.equal(value.audioUrl, '/media/abc/audio.mp3');
  assert.equal(value.videoUrl, '/media/abc/video.mp4');
});
