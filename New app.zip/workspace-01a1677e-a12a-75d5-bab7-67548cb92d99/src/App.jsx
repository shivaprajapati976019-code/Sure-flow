import React, { useCallback, useEffect, useRef, useState } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { AlertCircle, CheckCircle2, Home, Library, LoaderCircle, LockKeyhole, Plus, Settings, Sparkles, X } from 'lucide-react';
import { Youtube } from './components/YoutubeIcon.jsx';
import { api, getApiBase, getToken, hasServerConfig, isNative, setApiBase, setToken } from './api.js';
import { ACTIVE_STATUSES } from './data.js';
import { classNames } from './utils.js';
import { Logo } from './components/UI.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Create from './pages/Create.jsx';
import LibraryPage from './pages/Library.jsx';
import SettingsPage from './pages/Settings.jsx';
import JobDetail from './pages/JobDetail.jsx';

const NAV = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/library', label: 'Library', icon: Library },
  { path: '/create', label: 'Create', icon: Plus, create: true },
  { path: '/settings', label: 'Settings', icon: Settings },
];

function currentPath() {
  return window.location.hash.replace(/^#/, '') || '/';
}

export default function App() {
  const [route, setRoute] = useState(currentPath);
  const [data, setData] = useState(null);
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [needsAuth, setNeedsAuth] = useState(false);
  const [needsServer, setNeedsServer] = useState(false);
  const [serverError, setServerError] = useState('');
  const [toasts, setToasts] = useState([]);
  const [demoBusy, setDemoBusy] = useState(false);
  const toastCounter = useRef(0);

  const notify = useCallback((message, type = 'info') => {
    const id = ++toastCounter.current;
    setToasts((current) => [...current.slice(-2), { id, message, type }]);
    setTimeout(() => setToasts((current) => current.filter((toast) => toast.id !== id)), 4800);
  }, []);

  const navigate = useCallback((path) => {
    if (currentPath() === path) setRoute(path);
    else window.location.hash = path;
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const refresh = useCallback(async () => {
    const result = await api('/api/bootstrap');
    setData(result);
    setNeedsAuth(false);
    setServerError('');
    return result;
  }, []);

  const boot = useCallback(async () => {
    setLoading(true);
    if (!hasServerConfig()) {
      setNeedsServer(true);
      setLoading(false);
      return;
    }
    try {
      const healthResult = await api('/api/health');
      setHealth(healthResult);
      if (healthResult.authRequired && !getToken()) {
        setNeedsAuth(true);
        setData(null);
      } else await refresh();
    } catch (error) {
      if (error.status === 401) setNeedsAuth(true);
      else setServerError(error.message || 'Server se connect nahi ho paya.');
    } finally { setLoading(false); }
  }, [refresh]);

  useEffect(() => { boot(); }, [boot]);
  useEffect(() => {
    const onHash = () => setRoute(currentPath());
    const onUnauthorized = () => { setToken(''); setNeedsAuth(true); setData(null); };
    window.addEventListener('hashchange', onHash);
    window.addEventListener('surflow:unauthorized', onUnauthorized);
    return () => { window.removeEventListener('hashchange', onHash); window.removeEventListener('surflow:unauthorized', onUnauthorized); };
  }, []);
  useEffect(() => {
    if (!isNative) return;
    const listener = CapacitorApp.addListener('appUrlOpen', ({ url }) => {
      if (url.includes('youtube')) {
        refresh().then(() => notify('YouTube account connected.', 'success')).catch(() => {});
      }
    });
    return () => { listener.then((handle) => handle.remove()).catch(() => {}); };
  }, [refresh, notify]);
  useEffect(() => {
    if (!data) return;
    const youtube = new URLSearchParams(window.location.search).get('youtube');
    if (youtube) {
      notify(youtube === 'connected' ? 'YouTube account successfully connected.' : 'YouTube connection complete nahi hua.', youtube === 'connected' ? 'success' : 'error');
      const clean = `${window.location.pathname}${window.location.hash}`;
      window.history.replaceState({}, '', clean);
      refresh().catch(() => {});
    }
  }, [data, notify, refresh]);
  useEffect(() => {
    if (!data?.jobs?.some((job) => ACTIVE_STATUSES.includes(job.status))) return;
    const timer = setInterval(() => refresh().catch(() => {}), 3500);
    return () => clearInterval(timer);
  }, [data?.jobs, refresh]);

  async function startDemo() {
    setDemoBusy(true);
    try {
      const response = await api('/api/demo', { method: 'POST', body: {} });
      await refresh();
      notify('Local demo shuru—koi paid API call nahi hogi.', 'success');
      navigate(`/jobs/${response.job.id}`);
    } catch (error) { notify(error.message, 'error'); } finally { setDemoBusy(false); }
  }

  if (loading) return <Splash />;
  if (needsServer) return <ServerSetup onSuccess={async () => { setNeedsServer(false); setServerError(''); await boot(); }} />;
  if (needsAuth) return <Login onSuccess={async (token) => { setToken(token); setNeedsAuth(false); await boot(); }} />;
  if (serverError || !data) return <div className="fatal-screen"><Logo /><div className="fatal-card"><AlertCircle size={31} /><h1>Server se connection nahi hua</h1><p>{serverError || 'SurFlow server start karein aur page reload karein.'}</p><button className="btn btn-primary" onClick={boot}>Dobara try karein</button>{isNative && <button className="btn btn-ghost" onClick={() => setNeedsServer(true)}>Server URL badlein</button>}<code>{getApiBase() || 'npm run dev'}</code></div></div>;

  let page;
  if (route === '/create') page = <Create data={data} navigate={navigate} notify={notify} refresh={refresh} />;
  else if (route === '/library') page = <LibraryPage jobs={data.jobs} navigate={navigate} onDemo={startDemo} />;
  else if (route === '/settings') page = <SettingsPage data={data} refresh={refresh} notify={notify} navigate={navigate} />;
  else if (route.startsWith('/jobs/')) page = <JobDetail job={data.jobs.find((job) => job.id === route.split('/')[2])} navigate={navigate} notify={notify} refresh={refresh} />;
  else page = <Dashboard data={data} refresh={refresh} navigate={navigate} notify={notify} onDemo={startDemo} demoBusy={demoBusy} />;

  const activeCount = data.jobs.filter((job) => ACTIVE_STATUSES.includes(job.status)).length;
  return <div className="app-shell">
    <aside className="sidebar">
      <button className="logo-button" onClick={() => navigate('/')}><Logo /></button>
      <nav className="sidebar-nav">{NAV.map((item) => <NavButton key={item.path} item={item} route={route} navigate={navigate} />)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-automation"><div className="automation-pulse"><span className={classNames('pulse-dot', data.settings.autoPublish && 'on')} /><strong>Automation {data.settings.autoPublish ? 'ON' : 'OFF'}</strong></div><p>{activeCount ? `${activeCount} release${activeCount > 1 ? 's' : ''} in progress` : 'Studio ready for your idea'}</p><div className="mini-progress"><i style={{ width: `${([data.secrets.geminiApiKey || data.secrets.openaiApiKey, data.secrets.musicgptApiKey, data.youtube.connected].filter(Boolean).length / 3) * 100}%` }} /></div></div>
      <div className="sidebar-profile"><span className="profile-avatar">SF</span><div><strong>My Studio</strong><small>{data.youtube.connected ? data.youtube.channelTitle || 'YouTube connected' : 'Personal workspace'}</small></div><span className="online-dot" /></div>
    </aside>

    <header className="mobile-header"><button className="logo-button" onClick={() => navigate('/')}><Logo /></button><button className={classNames('mobile-youtube', data.youtube.connected && 'connected')} onClick={() => navigate('/settings')}><Youtube size={18} /><span>{data.youtube.connected ? 'Connected' : 'Connect'}</span></button></header>
    <main className="main-content">{page}</main>
    <nav className="bottom-nav">{NAV.map((item) => <NavButton key={item.path} item={item} route={route} navigate={navigate} mobile />)}</nav>
    <div className="toast-stack" aria-live="polite">{toasts.map((toast) => <div className={classNames('toast', `toast-${toast.type}`)} key={toast.id}>{toast.type === 'success' ? <CheckCircle2 size={18} /> : toast.type === 'error' ? <AlertCircle size={18} /> : <Sparkles size={18} />}<span>{toast.message}</span><button onClick={() => setToasts((current) => current.filter((item) => item.id !== toast.id))}><X size={15} /></button></div>)}</div>
  </div>;
}

function NavButton({ item, route, navigate, mobile = false }) {
  const active = item.path === '/' ? route === '/' : route.startsWith(item.path);
  const Icon = item.icon;
  return <button className={classNames('nav-button', active && 'active', item.create && 'create-nav', mobile && 'mobile-nav-button')} onClick={() => navigate(item.path)}><span><Icon size={mobile ? 20 : 19} /></span><label>{item.label}</label>{!mobile && item.create && <kbd>＋</kbd>}</button>;
}

function Splash() {
  return <div className="splash-screen"><Logo /><div className="splash-loader"><LoaderCircle size={24} className="spin" /></div><p>Aapka studio taiyar ho raha hai…</p></div>;
}

function ServerSetup({ onSuccess }) {
  const [url, setUrl] = useState(getApiBase());
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault();
    setBusy(true); setError('');
    try { setApiBase(url); await onSuccess(); }
    catch (err) { setError(err.message || 'Valid HTTPS server URL enter karein.'); setBusy(false); }
  }
  return <div className="login-screen"><div className="login-glow" /><div className="login-card"><Logo /><div className="login-icon"><Settings size={24} /></div><h1>SurFlow server jodein</h1><p>Android app ke liye apne deployed SurFlow backend ka HTTPS URL enter karein. Yeh sirf ek baar karna hoga.</p><form onSubmit={submit}><label>Backend server URL</label><input type="url" value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://surflow-api.onrender.com" autoFocus />{error && <div className="login-error"><AlertCircle size={15} />{error}</div>}<button className="btn btn-primary btn-full" disabled={busy || !url}>{busy ? <LoaderCircle size={18} className="spin" /> : 'Server connect karein'}</button></form><small><LockKeyhole size={12} />URL isi device par save hoga. API keys sirf server par rengi.</small></div></div>;
}

function Login({ onSuccess }) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(event) {
    event.preventDefault();
    setBusy(true); setError('');
    try { const result = await api('/api/session', { method: 'POST', body: { accessCode: code } }); await onSuccess(result.token); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <div className="login-screen"><div className="login-glow" /><div className="login-card"><Logo /><div className="login-icon"><LockKeyhole size={25} /></div><h1>Aapka private music studio</h1><p>Server par set kiya hua access code enter karein.</p><form onSubmit={submit}><label>Workspace access code</label><input type="password" value={code} onChange={(event) => setCode(event.target.value)} placeholder="••••••••••••" autoFocus />{error && <div className="login-error"><AlertCircle size={15} />{error}</div>}<button className="btn btn-primary btn-full" disabled={busy || !code}>{busy ? <LoaderCircle size={18} className="spin" /> : 'Studio unlock karein'}</button></form><small><LockKeyhole size={12} />API keys aur YouTube tokens is workspace ke andar encrypted rehte hain.</small></div></div>;
}
