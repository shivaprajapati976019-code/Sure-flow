import { getSecret } from './secrets.js';
import { getSettings } from './store.js';
import { AppError } from './errors.js';
import { asString, fetchChecked, parseJsonPayload } from './utils.js';

function textKey(provider) {
  const key = (provider === 'openai' ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY) || getSecret(provider === 'openai' ? 'openaiApiKey' : 'geminiApiKey');
  if (!key) {
    throw new AppError(
      `${provider === 'openai' ? 'OpenAI' : 'Gemini'} API key Settings mein add karein. Website login hi kaafi nahi hai.`,
      412,
      'TEXT_API_REQUIRED',
    );
  }
  return key;
}

async function askJson(system, prompt) {
  const settings = getSettings();
  const provider = settings.textProvider;
  const key = textKey(provider);
  let content;

  if (provider === 'openai') {
    const body = await fetchChecked('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: settings.openaiModel,
        temperature: 0.85,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: prompt },
        ],
      }),
    }, 'OpenAI');
    content = body?.choices?.[0]?.message?.content;
  } else {
    const model = encodeURIComponent(settings.geminiModel || 'gemini-3.6-flash');
    const body = await fetchChecked(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.9, maxOutputTokens: 8192, responseMimeType: 'application/json' },
      }),
    }, 'Gemini');
    content = body?.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join('');
  }

  if (!content) throw new AppError('AI ne khaali response diya. Model name aur API access check karein.', 502, 'AI_EMPTY_RESPONSE');
  return parseJsonPayload(content);
}

function truncateAtBreak(text, max) {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const line = cut.lastIndexOf('\n');
  return cut.slice(0, line > max * 0.8 ? line : max).trim();
}

export function normalizeCreative(raw, input = {}) {
  const lyrics = asString(raw?.lyrics, 6000);
  const style = asString(raw?.style, 1200);
  if (!lyrics && !input.instrumental) throw new AppError('AI response mein lyrics nahi mile. Dobara generate karein.', 502, 'AI_INVALID_CREATIVE');
  if (!style) throw new AppError('AI response mein music style nahi mila.', 502, 'AI_INVALID_CREATIVE');
  return {
    songTitle: asString(raw?.songTitle || raw?.title || input.topic || 'Naya Gaana', 90).replace(/[<>]/g, ''),
    lyrics: truncateAtBreak(lyrics, 2900),
    style: truncateAtBreak(style, 900),
    negativeTags: asString(raw?.negativeTags || 'distorted vocals, clipped audio, excessive noise', 500),
  };
}

export function normalizeMetadata(raw, creative = {}) {
  const title = asString(raw?.title || creative.songTitle || 'Naya Gaana', 120).replace(/[<>]/g, '').slice(0, 100);
  const description = asString(raw?.description, 5000).replace(/[<>]/g, '');
  const tags = Array.isArray(raw?.tags) ? raw.tags : asString(raw?.tags).split(',');
  const cleanTags = [];
  let tagLength = 0;
  for (const item of tags) {
    const tag = asString(item, 60).replace(/[<>,]/g, '');
    if (!tag || cleanTags.includes(tag)) continue;
    if (tagLength + tag.length + 1 > 480 || cleanTags.length >= 15) break;
    cleanTags.push(tag);
    tagLength += tag.length + 1;
  }
  const hashtags = (Array.isArray(raw?.hashtags) ? raw.hashtags : [])
    .map((tag) => asString(tag, 40).replace(/\s+/g, ''))
    .filter(Boolean)
    .map((tag) => tag.startsWith('#') ? tag : `#${tag}`)
    .slice(0, 5);
  return { title, description, tags: cleanTags, hashtags };
}

export async function generateCreative(input) {
  const system = `You are an original songwriter and music director for an independent creator. Return only one valid JSON object. Never reproduce existing lyrics, melodies, catchphrases, or imitate a named artist. Write singable, natural lines with a clear hook. Do not add markdown or commentary.`;
  const prompt = `Create an original song package from this brief:
Topic: ${asString(input.topic, 600)}
Language: ${asString(input.language || 'Hinglish', 60)}
Genre: ${asString(input.genre || 'Bollywood pop', 100)}
Mood: ${asString(input.mood || 'Emotional', 100)}
Vocals: ${input.instrumental ? 'Instrumental only' : asString(input.vocalGender || 'neutral', 30)}
Target duration: ${Number(input.duration) || 180} seconds
Extra direction: ${asString(input.details || 'None', 800)}

JSON schema:
{
  "songTitle": "short original working title",
  "lyrics": "lyrics with [Intro], [Verse 1], [Chorus], [Verse 2], [Chorus], [Bridge], [Outro] labels; maximum 2500 characters; empty for instrumental",
  "style": "detailed production direction with genre, tempo/BPM, instruments, vocal character, energy arc and mix; maximum 800 characters; no artist names",
  "negativeTags": "short comma-separated unwanted production traits"
}
Keep the chorus memorable and repeatable. Use Devanagari only if explicitly requested; for Hindi or Hinglish use natural Roman script so it is easy to edit.`;
  return normalizeCreative(await askJson(system, prompt), input);
}

export async function generateMetadata(input, creative) {
  const settings = getSettings();
  const system = `You are a YouTube music release editor. Return only one valid JSON object. Metadata must be accurate, original, searchable and free of clickbait, keyword stuffing, < and > characters. Never claim an official affiliation that is not provided.`;
  const prompt = `Write YouTube metadata for this original AI-assisted song.
Working title: ${creative.songTitle}
Artist/channel: ${asString(settings.artistName || 'Independent artist', 100)}
Language: ${asString(input.language || 'Hinglish', 60)}
Genre: ${asString(input.genre || 'Music', 100)}
Mood: ${asString(input.mood || '', 100)}
Topic: ${asString(input.topic, 600)}
Lyrics excerpt: ${asString(creative.lyrics, 900)}

JSON schema:
{
 "title": "compelling accurate title, maximum 100 characters",
 "description": "2 short engaging paragraphs, then a compact credits line mentioning AI-assisted production, then 3 relevant hashtags; maximum 3500 characters",
 "tags": ["up to 12 relevant search tags"],
 "hashtags": ["up to 3 relevant hashtags"]
}`;
  return normalizeMetadata(await askJson(system, prompt), creative);
}
