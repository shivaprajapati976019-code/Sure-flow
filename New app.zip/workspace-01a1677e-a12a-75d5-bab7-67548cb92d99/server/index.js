import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { PORT, PUBLIC_URL, DIST_DIR, MEDIA_DIR, UPLOAD_DIR, YOUTUBE_CALLBACK, VERSION, IS_PRODUCTION } from './config.js';
import { authRequired, createSession, requireAuth } from './auth.js';
import { AppError, asyncRoute, publicError } from './errors.js';
import { getSettings, getYoutube, publicBootstrap, updateSettings } from './store.js';
import { SECRET_FIELDS, secretStatus, setSecret, deleteSecret } from './secrets.js';
import { generateCreative, generateMetadata } from './ai.js';
import { completeYoutubeAuth, disconnectYoutube, youtubeAuthUrl } from './youtube.js';
import { createDemoJob, createJob, publicJob, publicJobs, publishJob, recoverInterruptedJobs, retryJob } from './pipeline.js';
import { asString, safeExtension } from './utils.js';

const app = express();
app.disable('x-powered-by');
app.use(cors({ origin: true, methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'] }));
app.use(express.json({ limit: '2mb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});
app.use('/media', express.static(MEDIA_DIR, { index: false, dotfiles: 'deny', maxAge: IS_PRODUCTION ? '1h' : 0 }));

const tickets = new Map();
const states = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, value] of tickets) if (value.expiry < now) tickets.delete(key);
  for (const [key, value] of states) if (value.expiry < now) states.delete(key);
}, 60_000).unref();

function callbackPage(success, platform) {
  const title = success ? 'YouTube connected' : 'Connection failed';
  const message = success ? 'Ab SurFlow par wapas jaayein. Aap YouTube account jod chuke hain.' : 'Authorization complete nahi hui. SurFlow mein wapas jaakar dobara try karein.';
  if (success && platform === 'android') return `<!doctype html><meta name="viewport" content="width=device-width"><title>${title}</title><style>body{font-family:system-ui;background:#0b0d0f;color:#f5f6f2;display:grid;place-items:center;min-height:90vh;text-align:center;padding:24px}a{display:inline-block;background:#c6f56f;color:#10130d;padding:14px 22px;border-radius:14px;text-decoration:none;font-weight:700}</style><div><h1>${title}</h1><p>${message}</p><a href="surflow://youtube?connected=1">SurFlow kholein</a><script>location.href='surflow://youtube?connected=1'</script></div>`;
  const destination = success ? `${process.env.WEB_APP_URL || PUBLIC_URL}/?youtube=connected` : `${process.env.WEB_APP_URL || PUBLIC_URL}/?youtube=error`;
  return `<!doctype html><meta name="viewport" content="width=device-width"><title>${title}</title><style>body{font-family:system-ui;background:#0b0d0f;color:#f5f6f2;display:grid;place-items:center;min-height:90vh;text-align:center;padding:24px}a{display:inline-block;background:#c6f56f;color:#10130d;padding:14px 22px;border-radius:14px;text-decoration:none;font-weight:700}</style><div><h1>${title}</h1><p>${message}</p><a href="${destination}">SurFlow par wapas jaayein</a><script>setTimeout(()=>location.href=${JSON.stringify(destination)},900)</script></div>`;
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, app: 'SurFlow', version: VERSION, authRequired, serverTime: new Date().toISOString(), ffmpeg: true });
});
app.post('/api/session', (req, res) => {
  const token = createSession(req.body?.accessCode);
  if (!token) return res.status(401).json({ error: 'Access code sahi nahi hai.', code: 'INVALID_ACCESS_CODE' });
  res.json({ token, authRequired });
});
app.get('/api/auth/youtube/start', (req, res) => {
  const ticket = tickets.get(String(req.query.ticket || ''));
  if (!ticket || ticket.expiry < Date.now()) return res.status(400).send(callbackPage(false, 'web'));
  tickets.delete(String(req.query.ticket));
  const state = crypto.randomBytes(24).toString('base64url');
  states.set(state, { platform: ticket.platform, expiry: Date.now() + 10 * 60_000 });
  try { res.redirect(youtubeAuthUrl(state)); } catch (error) { res.status(error.status || 400).json(publicError(error)); }
});
app.get('/api/auth/youtube/callback', asyncRoute(async (req, res) => {
  const saved = states.get(String(req.query.state || ''));
  if (!saved || saved.expiry < Date.now()) return res.status(400).send(callbackPage(false, 'web'));
  states.delete(String(req.query.state));
  if (!req.query.code) return res.status(400).send(callbackPage(false, saved.platform));
  await completeYoutubeAuth(String(req.query.code));
  res.send(callbackPage(true, saved.platform));
}));

app.use('/api', requireAuth);

app.get('/api/bootstrap', (req, res) => {
  const data = publicBootstrap();
  const secrets = {
    ...data.secrets,
    geminiApiKey: Boolean(data.secrets.geminiApiKey || process.env.GEMINI_API_KEY),
    openaiApiKey: Boolean(data.secrets.openaiApiKey || process.env.OPENAI_API_KEY),
    musicgptApiKey: Boolean(data.secrets.musicgptApiKey || process.env.MUSICGPT_API_KEY),
    googleClientId: Boolean(data.secrets.googleClientId || process.env.GOOGLE_CLIENT_ID),
    googleClientSecret: Boolean(data.secrets.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET),
  };
  res.json({
    ...data,
    secrets,
    jobs: publicJobs(),
    youtube: { ...getYoutube(), tokenExpiry: undefined },
    capabilities: {
      authRequired, demo: true, android: true, builtinRenderer: true,
      publicUrl: PUBLIC_URL, youtubeCallback: YOUTUBE_CALLBACK, version: VERSION,
    },
  });
});

app.put('/api/settings', (req, res) => {
  const settings = updateSettings(req.body?.settings || {});
  const secrets = req.body?.secrets || {};
  const replacingGoogle = Boolean(secrets.googleClientId || secrets.googleClientSecret);
  if (replacingGoogle) disconnectYoutube();
  for (const field of SECRET_FIELDS) {
    if (['googleRefreshToken', 'googleAccessToken'].includes(field)) continue;
    if (typeof secrets[field] === 'string' && secrets[field].trim()) setSecret(field, secrets[field]);
  }
  res.json({ settings, secrets: { ...secretStatus(), geminiApiKey: Boolean(secretStatus().geminiApiKey || process.env.GEMINI_API_KEY) } });
});
app.delete('/api/settings/secrets/:name', (req, res) => {
  const allowed = ['geminiApiKey', 'openaiApiKey', 'musicgptApiKey', 'googleClientId', 'googleClientSecret'];
  if (!allowed.includes(req.params.name)) throw new AppError('Secret name valid nahi hai.', 400);
  deleteSecret(req.params.name);
  res.json({ ok: true });
});

app.post('/api/youtube/prepare', (req, res) => {
  // Validate before issuing a one-time ticket, so setup mistakes appear inside the app.
  youtubeAuthUrl('validation-only');
  const ticket = crypto.randomBytes(24).toString('base64url');
  const platform = req.body?.platform === 'android' ? 'android' : 'web';
  tickets.set(ticket, { platform, expiry: Date.now() + 5 * 60_000 });
  res.json({ url: `/api/auth/youtube/start?ticket=${ticket}`, absoluteUrl: `${PUBLIC_URL}/api/auth/youtube/start?ticket=${ticket}`, callback: YOUTUBE_CALLBACK });
});
app.post('/api/youtube/disconnect', (req, res) => {
  disconnectYoutube();
  res.json({ ok: true, youtube: getYoutube() });
});

const storage = multer.diskStorage({
  destination: (req, file, callback) => callback(null, UPLOAD_DIR),
  filename: (req, file, callback) => {
    const audio = req.params.kind === 'audio';
    const extension = safeExtension(file.originalname, audio ? ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac'] : ['.mp4'], audio ? '.mp3' : '.mp4');
    callback(null, `${crypto.randomUUID()}${extension}`);
  },
});
function fileFilter(req, file, callback) {
  const extension = path.extname(file.originalname).toLowerCase();
  const audio = req.params.kind === 'audio';
  const allowed = audio ? ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac'] : ['.mp4'];
  if (!allowed.includes(extension)) return callback(new AppError(audio ? 'MP3, WAV, M4A, AAC, OGG ya FLAC audio upload karein.' : 'External visualizer ka MP4 video upload karein.', 400, 'INVALID_FILE_TYPE'));
  callback(null, true);
}
const uploadAudio = multer({ storage, fileFilter, limits: { fileSize: 150 * 1024 * 1024, files: 1 } });
const uploadVideo = multer({ storage, fileFilter, limits: { fileSize: 1024 * 1024 * 1024, files: 1 } });
app.post('/api/uploads/:kind', (req, res, next) => {
  if (!['audio', 'video'].includes(req.params.kind)) return res.status(404).json({ error: 'Upload type valid nahi hai.' });
  const middleware = req.params.kind === 'audio' ? uploadAudio : uploadVideo;
  middleware.single('file')(req, res, (error) => {
    if (error) return next(error);
    if (!req.file) return res.status(400).json({ error: 'File select karein.', code: 'FILE_REQUIRED' });
    res.json({ id: req.file.filename, name: req.file.originalname, size: req.file.size, kind: req.params.kind });
  });
});

app.post('/api/creative', asyncRoute(async (req, res) => {
  if (asString(req.body?.topic).length < 3) throw new AppError('Song ka idea pehle likhein.', 400, 'TOPIC_REQUIRED');
  const creative = await generateCreative(req.body || {});
  res.json({ creative });
}));
app.post('/api/metadata', asyncRoute(async (req, res) => {
  if (!req.body?.creative?.songTitle) throw new AppError('Pehle lyrics aur style generate karein.', 400, 'CREATIVE_REQUIRED');
  const metadata = await generateMetadata(req.body.input || {}, req.body.creative);
  res.json({ metadata });
}));

app.get('/api/jobs', (req, res) => res.json({ jobs: publicJobs() }));
app.post('/api/jobs', (req, res) => res.status(202).json({ job: createJob(req.body || {}) }));
app.get('/api/jobs/:id', (req, res) => {
  const job = publicJob(req.params.id);
  if (!job) throw new AppError('Release nahi mila.', 404, 'JOB_NOT_FOUND');
  res.json({ job });
});
app.post('/api/jobs/:id/retry', (req, res) => res.status(202).json({ job: retryJob(req.params.id) }));
app.post('/api/jobs/:id/publish', asyncRoute(async (req, res) => {
  const job = await publishJob(req.params.id, req.body || {});
  res.json({ job });
}));
app.post('/api/demo', (req, res) => res.status(202).json({ job: createDemoJob(req.body || {}) }));

app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint nahi mila.', code: 'NOT_FOUND' }));

if (fs.existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR, { index: false, maxAge: IS_PRODUCTION ? '1h' : 0 }));
  app.use((req, res, next) => {
    if (!['GET', 'HEAD'].includes(req.method) || !req.accepts('html')) return next();
    res.sendFile(path.join(DIST_DIR, 'index.html'));
  });
}

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  if (error instanceof multer.MulterError) {
    const message = error.code === 'LIMIT_FILE_SIZE' ? 'File size limit se badi hai.' : `Upload error: ${error.message}`;
    return res.status(400).json({ error: message, code: error.code });
  }
  const status = error.status || 500;
  if (status >= 500) console.error('[SurFlow]', error);
  res.status(status).json(publicError(error));
});

recoverInterruptedJobs();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`SurFlow server ready on http://0.0.0.0:${PORT}`);
  console.log(`YouTube OAuth callback: ${YOUTUBE_CALLBACK}`);
});
