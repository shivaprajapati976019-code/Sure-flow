import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT_DIR = path.resolve(here, '..');
export const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT_DIR, 'data'));
export const MEDIA_DIR = path.join(DATA_DIR, 'media');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
export const DIST_DIR = path.join(ROOT_DIR, 'dist');

for (const dir of [DATA_DIR, MEDIA_DIR, UPLOAD_DIR]) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
}

export const PORT = Number(process.env.PORT || 3000);
export const IS_PRODUCTION = process.env.NODE_ENV === 'production';
export const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
export const APP_ACCESS_CODE = process.env.APP_ACCESS_CODE || '';
export const YOUTUBE_CALLBACK = `${PUBLIC_URL}/api/auth/youtube/callback`;
export const MAX_DAILY_UPLOADS = 20;
export const VERSION = '1.0.0';
