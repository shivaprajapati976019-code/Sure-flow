import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, AudioLines, Check, CheckCircle2, ChevronRight, CloudUpload, FileAudio, FileVideo, Lightbulb, Link2, Music2, PencilLine, Rocket, Settings2, ShieldCheck, Sparkles, Upload, WandSparkles } from 'lucide-react';
import { Youtube } from '../components/YoutubeIcon.jsx';
import { api, openExternal, uploadFile } from '../api.js';
import { GENRES, IDEAS, LANGUAGES, MOODS, PALETTES } from '../data.js';
import { fromLocalInput, classNames, fileSize } from '../utils.js';
import Visualizer from '../components/Visualizer.jsx';
import { InlineNotice, Spinner, Stepper, Toggle } from '../components/UI.jsx';

const STEPS = ['Idea', 'Sound', 'Video', 'Publish'];

function initialDraft(settings) {
  const base = {
    input: { topic: '', language: 'Hinglish', genre: 'Bollywood pop', mood: 'Romantic', details: '', duration: 180, vocalGender: 'neutral', instrumental: false },
    creative: null,
    metadata: null,
    options: {
      musicSource: 'auto', videoSource: 'builtin', audioUploadId: '', videoUploadId: '',
      autoPublish: settings.autoPublish, privacy: settings.privacy, scheduleAt: '',
      visualTemplate: settings.visualTemplate, visualPalette: settings.visualPalette,
      madeForKids: settings.madeForKids, containsSyntheticMedia: settings.containsSyntheticMedia,
    },
  };
  try {
    const saved = JSON.parse(localStorage.getItem('surflow_draft'));
    return saved ? { ...base, ...saved, input: { ...base.input, ...saved.input }, options: { ...base.options, ...saved.options } } : base;
  } catch { return base; }
}

export default function Create({ data, navigate, notify, refresh }) {
  const [draft] = useState(() => initialDraft(data.settings));
  const [step, setStep] = useState(1);
  const [input, setInput] = useState(draft.input);
  const [creative, setCreative] = useState(draft.creative);
  const [metadata, setMetadata] = useState(draft.metadata);
  const [options, setOptions] = useState(draft.options);
  const [audioFile, setAudioFile] = useState(null);
  const [videoFile, setVideoFile] = useState(null);
  const [audioObjectUrl, setAudioObjectUrl] = useState('');
  const [busy, setBusy] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);

  const textConnected = data.settings.textProvider === 'openai' ? data.secrets.openaiApiKey : data.secrets.geminiApiKey;
  const minSchedule = useMemo(() => {
    const date = new Date(Date.now() + 10 * 60_000);
    return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
  }, []);

  useEffect(() => {
    localStorage.setItem('surflow_draft', JSON.stringify({ input, creative, metadata, options }));
  }, [input, creative, metadata, options]);
  useEffect(() => () => { if (audioObjectUrl) URL.revokeObjectURL(audioObjectUrl); }, [audioObjectUrl]);

  const setField = (field, value) => setInput((current) => ({ ...current, [field]: value }));
  const setOption = (field, value) => setOptions((current) => ({ ...current, [field]: value }));
  const setCreativeField = (field, value) => setCreative((current) => ({ ...current, [field]: value }));
  const setMetadataField = (field, value) => setMetadata((current) => ({ ...current, [field]: value }));

  function basicMetadata() {
    return {
      title: creative?.songTitle || input.topic.slice(0, 80),
      description: `${creative?.songTitle || 'Yeh original gaana'} — ${input.genre}, ${input.mood.toLowerCase()} mood.\n\nAI-assisted original music.\n\n#OriginalMusic #${input.language.replace(/\s+/g, '')}`,
      tags: [input.genre, input.language, input.mood, 'original music'], hashtags: ['#OriginalMusic'],
    };
  }

  async function makeCreative() {
    if (input.topic.trim().length < 3) throw new Error('Pehle song ka idea likhein.');
    setBusy('creative');
    try {
      const response = await api('/api/creative', { method: 'POST', body: input });
      setCreative(response.creative);
      setMetadata(null);
      notify('Lyrics aur music style ready.', 'success');
      return response.creative;
    } catch (error) { notify(error.message, 'error'); throw error; } finally { setBusy(''); }
  }

  async function makeMetadata() {
    if (!creative) { notify('Pehle lyrics aur style generate karein.', 'error'); return null; }
    setBusy('metadata');
    try {
      const response = await api('/api/metadata', { method: 'POST', body: { input, creative } });
      setMetadata(response.metadata);
      notify('YouTube metadata ready.', 'success');
      return response.metadata;
    } catch (error) { notify(error.message, 'error'); throw error; } finally { setBusy(''); }
  }

  function makeManualCreative() {
    setCreative({
      songTitle: input.topic.trim().slice(0, 80) || 'Naya Gaana',
      lyrics: '',
      style: `${input.genre}, ${input.mood.toLowerCase()} mood, original production`,
      negativeTags: '',
    });
    setMetadata(null);
    notify('Manual editor ready—lyrics/style khud paste ya edit karein.', 'success');
  }

  async function handleFile(kind, file) {
    if (!file) return;
    const max = kind === 'audio' ? 150 * 1024 * 1024 : 1024 * 1024 * 1024;
    if (file.size > max) { notify('File size limit se badi hai.', 'error'); return; }
    setBusy(kind);
    setUploadProgress(0);
    try {
      const uploaded = await uploadFile(kind, file, setUploadProgress);
      if (kind === 'audio') {
        setAudioFile(uploaded);
        setOption('audioUploadId', uploaded.id);
        setOption('musicSource', 'upload');
        if (audioObjectUrl) URL.revokeObjectURL(audioObjectUrl);
        setAudioObjectUrl(URL.createObjectURL(file));
      } else {
        setVideoFile(uploaded);
        setOption('videoUploadId', uploaded.id);
        setOption('videoSource', 'external');
      }
      notify(`${kind === 'audio' ? 'Audio' : 'Video'} attach ho gaya.`, 'success');
    } catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }

  async function next() {
    if (step === 1) {
      if (input.topic.trim().length < 3) return notify('Song ka idea kam se kam kuch words mein likhein.', 'error');
      setStep(2);
    } else if (step === 2) {
      try {
        if (!creative) await makeCreative();
        if (options.musicSource === 'upload' && !options.audioUploadId) return notify('Audio upload karein ya AI Generate select karein.', 'error');
        setStep(3);
      } catch { /* generation already shows the error */ }
    } else if (step === 3) {
      if (options.videoSource === 'external' && !options.videoUploadId) return notify('Specterr/MusicVid se export kiya MP4 upload karein.', 'error');
      if (!metadata) {
        if (textConnected && creative) {
          try { await makeMetadata(); } catch { return; }
        } else {
          setMetadata(basicMetadata());
          if (!textConnected) notify('AI writer connected nahi hai—basic metadata ko ab edit kar sakte hain.', 'info');
        }
      }
      setStep(4);
    }
  }

  async function startJob(quick = false) {
    if (!rightsConfirmed) return notify('Content rights wale checkbox ko confirm karein.', 'error');
    if (input.topic.trim().length < 3) return notify('Song ka idea likhein.', 'error');
    if (quick && !textConnected) return notify('Full-auto ke liye pehle Gemini/OpenAI API key connect karein.', 'error');
    if (quick && options.musicSource === 'auto' && !data.secrets.musicgptApiKey) return notify('Full-auto music ke liye MusicGPT API key chahiye, ya step-by-step mein audio import karein.', 'error');
    setBusy('start');
    try {
      const finalOptions = { ...options, autoPublish: quick ? true : options.autoPublish, scheduleAt: options.scheduleAt ? fromLocalInput(options.scheduleAt) : null };
      const response = await api('/api/jobs', { method: 'POST', body: { input, creative, metadata, options: finalOptions, rightsConfirmed } });
      localStorage.removeItem('surflow_draft');
      await refresh();
      notify(quick ? 'Full-auto release pipeline shuru ho gayi.' : 'Release pipeline shuru ho gayi.', 'success');
      navigate(`/jobs/${response.job.id}`);
    } catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }

  return <div className="page create-page">
    <div className="page-heading create-heading"><div><button className="back-link" onClick={() => step > 1 ? setStep(step - 1) : navigate('/')}><ArrowLeft size={17} />{step > 1 ? 'Pichla step' : 'Dashboard'}</button><h1>Nayi release</h1><p>Ek idea, poora music-video workflow.</p></div><span className="draft-badge"><Check size={13} />Draft auto-saved</span></div>
    <Stepper steps={STEPS} current={step} />

    <div className="creator-layout">
      <div className="creator-main">
        {step === 1 && <section className="form-card">
          <div className="form-card-heading"><span className="form-icon lime"><Lightbulb size={21} /></span><div><h2>Gaana kis baare mein hai?</h2><p>Jitna clear idea, utha behtar lyrics aur sound.</p></div></div>
          <div className="field"><label>Song ka idea <span>*</span></label><textarea className="idea-input" value={input.topic} onChange={(event) => setField('topic', event.target.value)} placeholder="Jaise: Barish mein purani yaadon wali sad Hindi song, lekin ending mein hope ho…" maxLength={600} rows={4} /><small className="char-count">{input.topic.length}/600</small></div>
          <div className="idea-chips">{IDEAS.map((idea) => <button key={idea} onClick={() => setField('topic', idea)}>{idea}<PlusMark /></button>)}</div>
          <div className="form-grid three">
            <div className="field"><label>Language</label><select value={input.language} onChange={(event) => setField('language', event.target.value)}>{LANGUAGES.map((item) => <option key={item}>{item}</option>)}</select></div>
            <div className="field"><label>Genre</label><select value={input.genre} onChange={(event) => setField('genre', event.target.value)}>{GENRES.map((item) => <option key={item}>{item}</option>)}</select></div>
            <div className="field"><label>Mood</label><select value={input.mood} onChange={(event) => setField('mood', event.target.value)}>{MOODS.map((item) => <option key={item}>{item}</option>)}</select></div>
          </div>
          <div className="form-grid three">
            <div className="field"><label>Duration</label><select value={input.duration} onChange={(event) => setField('duration', Number(event.target.value))}><option value={60}>~1 minute</option><option value={120}>~2 minutes</option><option value={180}>~3 minutes</option><option value={240}>~4 minutes</option><option value={300}>~5 minutes</option></select></div>
            <div className="field"><label>Vocals</label><select value={input.vocalGender} onChange={(event) => setField('vocalGender', event.target.value)} disabled={input.instrumental}><option value="neutral">Neutral / any</option><option value="female">Female</option><option value="male">Male</option></select></div>
            <div className="field inline-toggle-field"><label>Instrumental</label><Toggle checked={input.instrumental} onChange={(value) => setField('instrumental', value)} /></div>
          </div>
          <div className="field"><label>Extra direction <small>optional</small></label><input value={input.details} onChange={(event) => setField('details', event.target.value)} placeholder="BPM, instruments, hook, story ya energy arc…" maxLength={800} /></div>
          <div className="quick-auto-card"><div><span className="quick-auto-icon"><Rocket size={21} /></span><div><strong>Review skip karke full-auto</strong><p>Default settings se lyrics → music → video → YouTube.</p></div></div><button className="btn btn-dark" onClick={() => startJob(true)} disabled={Boolean(busy)}>{busy === 'start' ? <Spinner /> : <WandSparkles size={17} />}Full-auto chalao</button></div>
        </section>}

        {step === 2 && <section className="form-card">
          <div className="form-card-heading"><span className="form-icon violet"><AudioLines size={21} /></span><div><h2>Lyrics aur sound</h2><p>AI output ko edit karein, phir music source chunein.</p></div></div>
          {!creative ? <div className="generate-empty"><span><Sparkles size={29} /></span><h3>Pehle song package banayein</h3><p>{data.settings.textProvider === 'openai' ? 'OpenAI' : 'Gemini'} original lyrics, working title aur detailed music style likhega.</p><div className="button-row"><button className="btn btn-primary" onClick={() => makeCreative().catch(() => {})} disabled={Boolean(busy)}>{busy === 'creative' ? <Spinner /> : <WandSparkles size={17} />}Lyrics + style banao</button><button className="btn btn-ghost" onClick={makeManualCreative} disabled={Boolean(busy)}><PencilLine size={16} />Manually likhunga/ likhungi</button></div>{!textConnected && <small>AI key nahi hai? Manual editor aur Audio Import phir bhi use kar sakte hain.</small>}</div> : <div className="creative-editor">
            <div className="field"><label>Working title</label><input value={creative.songTitle} onChange={(event) => setCreativeField('songTitle', event.target.value)} maxLength={90} /></div>
            <div className="field"><div className="label-row"><label>Lyrics</label><button className="text-button" onClick={() => makeCreative().catch(() => {})} disabled={Boolean(busy)}>{busy === 'creative' ? <Spinner size={14} /> : <Sparkles size={14} />}Dobara banao</button></div><textarea className="lyrics-input" value={creative.lyrics} onChange={(event) => setCreativeField('lyrics', event.target.value)} rows={14} maxLength={2900} placeholder={input.instrumental ? 'Instrumental selected—lyrics optional.' : '[Verse 1]…'} /><small className="char-count">{creative.lyrics.length}/2900</small></div>
            <div className="field"><label>Music style / production prompt</label><textarea value={creative.style} onChange={(event) => setCreativeField('style', event.target.value)} rows={4} maxLength={900} /><small className="char-count">{creative.style.length}/900</small></div>
          </div>}

          <div className="subsection-heading"><h3>Music kaise banega?</h3></div>
          <div className="choice-grid two">
            <button className={classNames('choice-card', options.musicSource === 'auto' && 'selected')} onClick={() => setOption('musicSource', 'auto')}><span className="choice-icon"><Sparkles size={20} /></span><div><strong>AI music generate</strong><small>MusicGPT official API se automatic</small></div><span className="radio-dot" /></button>
            <button className={classNames('choice-card', options.musicSource === 'upload' && 'selected')} onClick={() => setOption('musicSource', 'upload')}><span className="choice-icon"><Upload size={20} /></span><div><strong>Audio import</strong><small>Suno/MusicGPT website se downloaded file</small></div><span className="radio-dot" /></button>
          </div>
          {options.musicSource === 'auto' && !data.secrets.musicgptApiKey && <InlineNotice tone="warning" title="MusicGPT API key abhi connected nahi hai" action={<button className="text-button" onClick={() => navigate('/settings')}>Add key<ChevronRight size={14} /></button>}>Website account aur API billing alag ho sakte hain. Audio Import bhi use kar sakte hain.</InlineNotice>}
          {options.musicSource === 'upload' && <label className={classNames('upload-zone', options.audioUploadId && 'has-file')}><input type="file" accept="audio/mpeg,audio/wav,audio/mp4,audio/aac,audio/ogg,.flac" onChange={(event) => handleFile('audio', event.target.files?.[0])} />{busy === 'audio' ? <><Spinner size={28} /><strong>Uploading… {uploadProgress}%</strong><p>File server par securely ja rahi hai</p></> : options.audioUploadId ? <><CheckCircle2 size={30} /><strong>{audioFile?.name || 'Audio attached'}</strong><p>{audioFile ? fileSize(audioFile.size) : 'Saved draft ka uploaded audio'} • dobara choose karke replace karein</p></> : <><FileAudio size={31} /><strong>Song audio choose karein</strong><p>MP3, WAV, M4A, AAC, OGG ya FLAC • max 150 MB</p><span className="btn btn-ghost btn-small">Browse audio</span></>}</label>}
        </section>}

        {step === 3 && <section className="form-card">
          <div className="form-card-heading"><span className="form-icon orange"><FileVideo size={21} /></span><div><h2>Visualizer video</h2><p>Built-in automatic renderer ya external MP4.</p></div></div>
          <div className="choice-grid two visual-source-choice">
            <button className={classNames('choice-card', options.videoSource === 'builtin' && 'selected')} onClick={() => setOption('videoSource', 'builtin')}><span className="choice-icon"><WandSparkles size={20} /></span><div><strong>SurFlow visualizer</strong><small>Fully automatic • no watermark</small></div><span className="radio-dot" /></button>
            <button className={classNames('choice-card', options.videoSource === 'external' && 'selected')} onClick={() => setOption('videoSource', 'external')}><span className="choice-icon"><Link2 size={20} /></span><div><strong>External visualizer</strong><small>Specterr / MusicVid MP4 import</small></div><span className="radio-dot" /></button>
          </div>
          {options.videoSource === 'builtin' ? <>
            <Visualizer template={options.visualTemplate} paletteName={options.visualPalette} title={creative?.songTitle || input.topic} artist={data.settings.artistName || 'Original release'} audioUrl={audioObjectUrl} />
            <div className="preview-caption"><span><span className="live-dot" />LIVE STYLE PREVIEW</span><small>Final MP4 mein actual audio-reactivity hogi</small></div>
            <div className="template-grid">{[['nebula', 'Nebula orbit', 'Circular frequency rings'], ['pulse', 'Pulse wave', 'Smooth reactive waveform'], ['bars', 'Neon bars', 'Mirrored spectrum bars']].map(([id, name, description]) => <button key={id} className={classNames('template-card', options.visualTemplate === id && 'selected')} onClick={() => setOption('visualTemplate', id)}><span className={`template-art template-${id}`}><i /><i /><i /><i /><i /></span><strong>{name}</strong><small>{description}</small>{options.visualTemplate === id && <Check size={15} />}</button>)}</div>
            <div className="palette-row"><label>Color palette</label><div>{Object.entries(PALETTES).map(([id, palette]) => <button key={id} className={classNames('palette-button', options.visualPalette === id && 'selected')} onClick={() => setOption('visualPalette', id)} aria-label={palette.name}><span style={{ background: `linear-gradient(135deg, ${palette.first}, ${palette.second})` }} />{palette.name}{options.visualPalette === id && <Check size={13} />}</button>)}</div></div>
          </> : <div className="external-handoff">
            <InlineNotice title="External sites ka manual export chahiye">Specterr ke paas public automation API nahi hai. Audio wahan upload karke MP4 export karein, phir neeche attach karein—baaki metadata aur YouTube upload automatic hoga.</InlineNotice>
            <div className="external-links"><button className="btn btn-ghost" onClick={() => openExternal('https://specterr.com')}>Specterr kholein<ArrowRight size={16} /></button><button className="btn btn-ghost" onClick={() => openExternal('https://musicvid.org')}>MusicVid kholein<ArrowRight size={16} /></button></div>
            <label className={classNames('upload-zone', options.videoUploadId && 'has-file')}><input type="file" accept="video/mp4,.mp4" onChange={(event) => handleFile('video', event.target.files?.[0])} />{busy === 'video' ? <><Spinner size={28} /><strong>Video uploading… {uploadProgress}%</strong></> : options.videoUploadId ? <><CheckCircle2 size={30} /><strong>{videoFile?.name || 'External MP4 attached'}</strong><p>{videoFile ? fileSize(videoFile.size) : 'Saved draft ka video'} • replace karne ke liye choose karein</p></> : <><CloudUpload size={32} /><strong>Exported MP4 upload karein</strong><p>1080p ya 720p recommended • max 1 GB</p><span className="btn btn-ghost btn-small">Browse video</span></>}</label>
          </div>}
        </section>}

        {step === 4 && <section className="form-card">
          <div className="form-card-heading"><span className="form-icon red"><Youtube size={21} /></span><div><h2>YouTube release</h2><p>Metadata review karein aur publishing rules set karein.</p></div></div>
          <div className={classNames('youtube-connect-card', data.youtube.connected && 'connected')}><span><Youtube size={25} /></span><div><strong>{data.youtube.connected ? data.youtube.channelTitle || 'YouTube channel connected' : 'YouTube channel connect nahi hai'}</strong><small>{data.youtube.connected ? 'Secure OAuth connected • password stored nahi hota' : 'Upload se pehle secure Google connection chahiye'}</small></div>{data.youtube.connected ? <CheckCircle2 size={21} /> : <button className="btn btn-ghost btn-small" onClick={() => navigate('/settings')}>Connect<ArrowRight size={15} /></button>}</div>
          <div className="metadata-heading"><h3>Title & description</h3><button className="text-button" onClick={() => makeMetadata().catch(() => {})} disabled={Boolean(busy) || !creative}>{busy === 'metadata' ? <Spinner size={14} /> : <Sparkles size={14} />}AI se dobara likho</button></div>
          <div className="field"><label>YouTube title</label><input value={metadata?.title || ''} onChange={(event) => setMetadataField('title', event.target.value)} maxLength={100} /><small className="char-count">{metadata?.title?.length || 0}/100</small></div>
          <div className="field"><label>Description</label><textarea value={metadata?.description || ''} onChange={(event) => setMetadataField('description', event.target.value)} rows={8} maxLength={5000} /><small className="char-count">{metadata?.description?.length || 0}/5000</small></div>
          <div className="field"><label>Tags <small>comma separated</small></label><input value={metadata?.tags?.join(', ') || ''} onChange={(event) => setMetadataField('tags', event.target.value.split(',').map((tag) => tag.trim()).filter(Boolean).slice(0, 15))} /></div>
          <div className="subsection-heading"><h3>Visibility & timing</h3></div>
          <div className="privacy-grid">{[['public', 'Public', 'Turant sabke liye live'], ['unlisted', 'Unlisted', 'Sirf link wale dekh sakte hain'], ['private', 'Private', 'Sirf aap dekh sakte hain']].map(([id, name, description]) => <button key={id} className={classNames('privacy-option', options.privacy === id && 'selected')} onClick={() => setOption('privacy', id)}><span className="radio-dot" /><strong>{name}</strong><small>{description}</small></button>)}</div>
          <div className="field schedule-field"><label>Schedule publish <small>optional</small></label><input type="datetime-local" min={minSchedule} value={options.scheduleAt} onChange={(event) => setOption('scheduleAt', event.target.value)} /><small className="field-help">Scheduled video private upload hota hai aur selected time par YouTube use public karta hai.</small></div>
          <div className="publish-settings">
            <Toggle checked={options.autoPublish} onChange={(value) => setOption('autoPublish', value)} label="Automatic YouTube upload" description="Off karne par video download/review ke liye ready hoga" />
            <Toggle checked={options.containsSyntheticMedia} onChange={(value) => setOption('containsSyntheticMedia', value)} label="AI-generated content disclosure" description="YouTube ko synthetic/AI media ki jaankari dein" />
            <Toggle checked={options.madeForKids} onChange={(value) => setOption('madeForKids', value)} label="Made for kids" description="Sirf tab on karein jab content bachchon ke liye ho" />
          </div>
          <div className="release-summary"><span className="summary-icon"><Rocket size={22} /></span><div><strong>Release summary</strong><p>{creative?.songTitle || input.topic} • {input.genre} • {options.videoSource === 'builtin' ? options.visualTemplate : 'External MP4'} • {options.scheduleAt ? 'Scheduled' : options.privacy}</p></div></div>
        </section>}

        <label className="rights-check"><input type="checkbox" checked={rightsConfirmed} onChange={(event) => setRightsConfirmed(event.target.checked)} /><span className="custom-check">{rightsConfirmed && <Check size={14} />}</span><span>Main confirm karta/ karti hoon ki is content ko publish karne ka right mera hai aur main apne AI provider ke commercial terms follow karunga/ karungi.</span></label>

        <div className="creator-footer"><button className="btn btn-ghost" onClick={() => step === 1 ? navigate('/') : setStep(step - 1)} disabled={Boolean(busy)}><ArrowLeft size={17} />{step === 1 ? 'Cancel' : 'Back'}</button>{step < 4 ? <button className="btn btn-primary" onClick={next} disabled={Boolean(busy)}>{busy ? <Spinner /> : null}{step === 3 && !metadata && textConnected ? 'Metadata banao & aage badho' : 'Aage badho'}<ArrowRight size={17} /></button> : <button className="btn btn-primary btn-release" onClick={() => startJob(false)} disabled={Boolean(busy)}>{busy === 'start' ? <Spinner /> : <Rocket size={18} />}{options.autoPublish ? 'Release shuru karein' : 'Video ready karein'}</button>}</div>
      </div>

      <aside className="creator-aside">
        <div className="side-card release-routes"><span className="eyebrow">YOUR WORKFLOW</span><h3>Ek pipeline, saare steps</h3>{[['01', 'Original writing', 'Lyrics + music style', step > 1], ['02', 'Audio', options.musicSource === 'auto' ? 'MusicGPT generation' : 'Imported song', step > 2], ['03', 'HD visualizer', options.videoSource === 'builtin' ? `${options.visualTemplate} • 1280×720` : 'External MP4', step > 3], ['04', 'YouTube', options.autoPublish ? (options.scheduleAt ? 'Scheduled upload' : `${options.privacy} upload`) : 'Review only', false]].map(([number, title, subtitle, done], index) => <div className={classNames('route-step', step === index + 1 && 'current', done && 'done')} key={number}><span>{done ? <Check size={14} /> : number}</span><div><strong>{title}</strong><small>{subtitle}</small></div></div>)}</div>
        <div className="side-card safety-note"><ShieldCheck size={23} /><h3>Safe by design</h3><p>API keys encrypted server storage mein rehti hain. YouTube password kabhi nahi maanga jaata.</p><button className="text-button" onClick={() => navigate('/settings')}><Settings2 size={14} />Connections manage karein</button></div>
        {(creative || options.audioUploadId) && <div className="side-card attached-card"><span className="eyebrow">ATTACHED TO DRAFT</span>{creative && <div><PencilLine size={17} /><span><strong>{creative.songTitle}</strong><small>Lyrics + style ready</small></span></div>}{options.audioUploadId && <div><Music2 size={17} /><span><strong>Custom audio</strong><small>Upload attached</small></span></div>}</div>}
      </aside>
    </div>
  </div>;
}

function PlusMark() {
  return <span aria-hidden="true">+</span>;
}
