import React, { useState } from 'react';
import { ArrowRight, Bot, Check, CheckCircle2, ChevronDown, CircleAlert, Copy, ExternalLink, Eye, EyeOff, FileKey2, KeyRound, Link2, LockKeyhole, Music2, Palette, Rocket, ShieldCheck, SlidersHorizontal, Sparkles, Trash2 } from 'lucide-react';
import { Youtube } from '../components/YoutubeIcon.jsx';
import { api, isNative, openExternal } from '../api.js';
import { PALETTES } from '../data.js';
import { classNames } from '../utils.js';
import { InlineNotice, Spinner, Toggle } from '../components/UI.jsx';

export default function Settings({ data, refresh, notify, navigate }) {
  const [tab, setTab] = useState('connections');
  const [provider, setProvider] = useState(data.settings.textProvider);
  const [geminiModel, setGeminiModel] = useState(data.settings.geminiModel);
  const [openaiModel, setOpenaiModel] = useState(data.settings.openaiModel);
  const [musicModel, setMusicModel] = useState(data.settings.musicModel);
  const [keys, setKeys] = useState({ geminiApiKey: '', openaiApiKey: '', musicgptApiKey: '', googleClientId: '', googleClientSecret: '' });
  const [visible, setVisible] = useState({});
  const [busy, setBusy] = useState('');
  const [automation, setAutomation] = useState({ ...data.settings });

  const setKey = (name, value) => setKeys((current) => ({ ...current, [name]: value }));
  async function save(section, settings = {}, secrets = {}, success = 'Settings save ho gayi.') {
    setBusy(section);
    try {
      await api('/api/settings', { method: 'PUT', body: { settings, secrets } });
      setKeys((current) => Object.fromEntries(Object.keys(current).map((key) => [key, secrets[key] ? '' : current[key]])));
      await refresh();
      notify(success, 'success');
      return true;
    } catch (error) { notify(error.message, 'error'); return false; } finally { setBusy(''); }
  }
  async function removeSecret(name) {
    if (!window.confirm('Kya aap yeh saved API credential remove karna chahte hain?')) return;
    setBusy(name);
    try { await api(`/api/settings/secrets/${name}`, { method: 'DELETE' }); await refresh(); notify('Credential remove ho gaya.', 'success'); }
    catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }
  async function connectYoutube() {
    setBusy('youtube');
    try {
      if (keys.googleClientId || keys.googleClientSecret) {
        await api('/api/settings', { method: 'PUT', body: { secrets: { googleClientId: keys.googleClientId, googleClientSecret: keys.googleClientSecret } } });
        setKey('googleClientId', ''); setKey('googleClientSecret', '');
      }
      const response = await api('/api/youtube/prepare', { method: 'POST', body: { platform: isNative ? 'android' : 'web' } });
      if (isNative) await openExternal(response.absoluteUrl);
      else window.location.href = response.url;
    } catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }
  async function disconnectYoutube() {
    if (!window.confirm('YouTube connection remove karein? Saved videos delete nahi honge.')) return;
    setBusy('disconnect');
    try { await api('/api/youtube/disconnect', { method: 'POST' }); await refresh(); notify('YouTube disconnected.', 'success'); }
    catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }
  async function copyCallback() {
    try { await navigator.clipboard.writeText(data.capabilities.youtubeCallback); notify('OAuth callback URL copy ho gaya.', 'success'); }
    catch { notify(data.capabilities.youtubeCallback, 'info'); }
  }

  return <div className="page settings-page">
    <div className="page-heading"><div><span className="eyebrow">PERSONAL WORKSPACE</span><h1>Settings & connections</h1><p>API services, YouTube aur automation preferences manage karein.</p></div></div>
    <div className="settings-tabs">{[['connections', 'Connections', Link2], ['automation', 'Automation', SlidersHorizontal], ['guide', 'Setup guide', FileKey2]].map(([id, label, Icon]) => <button key={id} className={classNames(tab === id && 'selected')} onClick={() => setTab(id)}><Icon size={17} />{label}</button>)}</div>

    {tab === 'connections' && <div className="settings-layout"><div className="settings-main">
      <section className="settings-card">
        <div className="settings-card-heading"><span className="form-icon violet"><Bot size={21} /></span><div><h2>AI writer</h2><p>Lyrics, music style aur YouTube metadata ke liye.</p></div><ConnectionBadge connected={provider === 'openai' ? data.secrets.openaiApiKey : data.secrets.geminiApiKey} /></div>
        <div className="choice-grid two provider-choice">{[['gemini', 'Google Gemini', 'Recommended'], ['openai', 'OpenAI GPT', 'Chat Completions API']].map(([id, name, sub]) => <button key={id} className={classNames('choice-card', provider === id && 'selected')} onClick={() => setProvider(id)}><span className="choice-icon"><Sparkles size={19} /></span><div><strong>{name}</strong><small>{sub}</small></div><span className="radio-dot" /></button>)}</div>
        {provider === 'gemini' ? <div className="provider-form"><SecretField label="Gemini API key" name="geminiApiKey" value={keys.geminiApiKey} configured={data.secrets.geminiApiKey} visible={visible.geminiApiKey} onVisible={() => setVisible((v) => ({ ...v, geminiApiKey: !v.geminiApiKey }))} onChange={setKey} placeholder="AIza…" /><div className="field"><label>Gemini model</label><input value={geminiModel} onChange={(event) => setGeminiModel(event.target.value)} /><small className="field-help">Default: gemini-3.6-flash. Aap apne account ka available stable model use kar sakte hain.</small></div><div className="settings-actions"><button className="text-button" onClick={() => openExternal('https://aistudio.google.com/apikey')}>Google AI Studio key<ExternalLink size={14} /></button><div>{data.secrets.geminiApiKey && <button className="icon-button danger" onClick={() => removeSecret('geminiApiKey')} title="Remove key"><Trash2 size={16} /></button>}<button className="btn btn-primary btn-small" onClick={() => save('ai', { textProvider: provider, geminiModel, openaiModel }, { geminiApiKey: keys.geminiApiKey })} disabled={Boolean(busy)}>{busy === 'ai' ? <Spinner /> : <Check size={16} />}Save AI writer</button></div></div></div> : <div className="provider-form"><SecretField label="OpenAI API key" name="openaiApiKey" value={keys.openaiApiKey} configured={data.secrets.openaiApiKey} visible={visible.openaiApiKey} onVisible={() => setVisible((v) => ({ ...v, openaiApiKey: !v.openaiApiKey }))} onChange={setKey} placeholder="sk-…" /><div className="field"><label>OpenAI model</label><input value={openaiModel} onChange={(event) => setOpenaiModel(event.target.value)} /><small className="field-help">JSON response support wala model choose karein.</small></div><div className="settings-actions"><button className="text-button" onClick={() => openExternal('https://platform.openai.com/api-keys')}>OpenAI API keys<ExternalLink size={14} /></button><div>{data.secrets.openaiApiKey && <button className="icon-button danger" onClick={() => removeSecret('openaiApiKey')} title="Remove key"><Trash2 size={16} /></button>}<button className="btn btn-primary btn-small" onClick={() => save('ai', { textProvider: provider, geminiModel, openaiModel }, { openaiApiKey: keys.openaiApiKey })} disabled={Boolean(busy)}>{busy === 'ai' ? <Spinner /> : <Check size={16} />}Save AI writer</button></div></div></div>}
      </section>

      <section className="settings-card">
        <div className="settings-card-heading"><span className="form-icon lime"><Music2 size={21} /></span><div><h2>Music generation</h2><p>Full-auto audio ke liye MusicGPT Public API.</p></div><ConnectionBadge connected={data.secrets.musicgptApiKey} /></div>
        <InlineNotice title="Website login ≠ API access">Suno/MusicGPT website ka normal account browser automation ke liye use nahi kiya jaata. Official API key aur applicable API credits chahiye. Suno se downloaded audio ko Creator → Audio Import mein use karein.</InlineNotice>
        <SecretField label="MusicGPT API key" name="musicgptApiKey" value={keys.musicgptApiKey} configured={data.secrets.musicgptApiKey} visible={visible.musicgptApiKey} onVisible={() => setVisible((v) => ({ ...v, musicgptApiKey: !v.musicgptApiKey }))} onChange={setKey} placeholder="MusicGPT dashboard se API key…" />
        <div className="field"><label>Music model</label><select value={musicModel} onChange={(event) => setMusicModel(event.target.value)}><option value="v6">v6 — fastest / economical</option><option value="v6-pro">v6-pro</option><option value="v7">v7 — balanced</option><option value="v7-pro">v7-pro — highest quality</option></select><small className="field-help">Generation cost aur speed aapke MusicGPT plan par depend karegi.</small></div>
        <div className="settings-actions"><button className="text-button" onClick={() => openExternal('https://musicgpt.com/api-dashboard')}>MusicGPT API dashboard<ExternalLink size={14} /></button><div>{data.secrets.musicgptApiKey && <button className="icon-button danger" onClick={() => removeSecret('musicgptApiKey')}><Trash2 size={16} /></button>}<button className="btn btn-primary btn-small" onClick={() => save('music', { musicModel }, { musicgptApiKey: keys.musicgptApiKey })} disabled={Boolean(busy)}>{busy === 'music' ? <Spinner /> : <Check size={16} />}Save music API</button></div></div>
      </section>

      <section className="settings-card">
        <div className="settings-card-heading"><span className="form-icon red"><Youtube size={21} /></span><div><h2>YouTube channel</h2><p>Secure Google OAuth—channel password kabhi share na karein.</p></div><ConnectionBadge connected={data.youtube.connected} /></div>
        {data.youtube.connected && <div className="connected-account"><span className="youtube-icon"><Youtube size={23} /></span><div><strong>{data.youtube.channelTitle || 'Your YouTube channel'}</strong><small>Upload + read-only channel access</small></div><button className="btn btn-ghost btn-small" onClick={disconnectYoutube}>Disconnect</button></div>}
        <details className="oauth-details" open={!data.youtube.connected}><summary>Google Cloud OAuth configuration<ChevronDown size={16} /></summary><div className="oauth-body"><div className="oauth-fields"><SecretField label="OAuth Client ID" name="googleClientId" value={keys.googleClientId} configured={data.secrets.googleClientId} visible={visible.googleClientId} onVisible={() => setVisible((v) => ({ ...v, googleClientId: !v.googleClientId }))} onChange={setKey} placeholder="…apps.googleusercontent.com" /><SecretField label="OAuth Client Secret" name="googleClientSecret" value={keys.googleClientSecret} configured={data.secrets.googleClientSecret} visible={visible.googleClientSecret} onVisible={() => setVisible((v) => ({ ...v, googleClientSecret: !v.googleClientSecret }))} onChange={setKey} placeholder="GOCSPX-…" /></div><div className="field"><label>Authorized redirect URI</label><div className="copy-field"><code>{data.capabilities.youtubeCallback}</code><button onClick={copyCallback}><Copy size={16} /></button></div><small className="field-help">Google Cloud → Web OAuth client mein exactly yahi URI add karein.</small></div><div className="settings-actions"><button className="text-button" onClick={() => openExternal('https://console.cloud.google.com/apis/library/youtube.googleapis.com')}>Google Cloud kholein<ExternalLink size={14} /></button><button className="btn btn-primary btn-small" onClick={connectYoutube} disabled={Boolean(busy)}>{busy === 'youtube' ? <Spinner /> : <Youtube size={16} />}{data.youtube.connected ? 'Reconnect channel' : 'Save & connect YouTube'}</button></div></div></details>
      </section>

      <section className="settings-card external-services"><div className="settings-card-heading"><span className="form-icon orange"><ExternalLink size={21} /></span><div><h2>Website workflow</h2><p>In tools se export karke SurFlow mein import karein.</p></div></div><div className="service-links">{[['Suno', 'AI song audio', 'https://suno.com'], ['Specterr', 'Visualizer MP4', 'https://specterr.com'], ['MusicVid', 'Free visualizer', 'https://musicvid.org']].map(([name, sub, url]) => <button key={name} onClick={() => openExternal(url)}><span><strong>{name}</strong><small>{sub}</small></span><ExternalLink size={16} /></button>)}</div></section>
    </div><SettingsAside data={data} navigate={navigate} /></div>}

    {tab === 'automation' && <div className="settings-layout"><div className="settings-main">
      <section className="settings-card"><div className="settings-card-heading"><span className="form-icon lime"><Rocket size={21} /></span><div><h2>Release defaults</h2><p>Har nayi release par pehle se apply honge.</p></div></div><div className="form-grid two"><div className="field"><label>Artist / channel display name</label><input value={automation.artistName} onChange={(event) => setAutomation((a) => ({ ...a, artistName: event.target.value }))} placeholder="Aapka artist name" maxLength={100} /></div><div className="field"><label>Default visibility</label><select value={automation.privacy} onChange={(event) => setAutomation((a) => ({ ...a, privacy: event.target.value }))}><option value="public">Public</option><option value="unlisted">Unlisted</option><option value="private">Private</option></select></div></div><div className="publish-settings"><Toggle checked={automation.autoPublish} onChange={(value) => setAutomation((a) => ({ ...a, autoPublish: value }))} label="Full-auto YouTube publish" description="Video aur metadata ready hote hi upload" /><Toggle checked={automation.containsSyntheticMedia} onChange={(value) => setAutomation((a) => ({ ...a, containsSyntheticMedia: value }))} label="AI content disclosure" description="YouTube synthetic media flag bhejein" /><Toggle checked={automation.madeForKids} onChange={(value) => setAutomation((a) => ({ ...a, madeForKids: value }))} label="Made for kids" description="Default audience setting" /></div></section>
      <section className="settings-card"><div className="settings-card-heading"><span className="form-icon orange"><ShieldCheck size={21} /></span><div><h2>Upload safety</h2><p>Accidental ya repeated uploads se bachav.</p></div></div><div className="field"><label>Daily upload limit</label><div className="number-field"><input type="number" min="1" max="20" value={automation.dailyLimit} onChange={(event) => setAutomation((a) => ({ ...a, dailyLimit: Number(event.target.value) }))} /><span>uploads / day</span></div><small className="field-help">1–20. Limit poori hone par existing video delete nahi hota; upload ruk jaata hai.</small></div><InlineNotice title="Public upload aur Google approval">Naye/unaudited Google API projects par public publishing restrictions ho sakti hain. Agar video private lock ho, YouTube Studio aur Google Cloud API compliance status check karein.</InlineNotice></section>
      <section className="settings-card"><div className="settings-card-heading"><span className="form-icon violet"><Palette size={21} /></span><div><h2>Visualizer defaults</h2><p>Har release mein badla ja sakta hai.</p></div></div><div className="form-grid two"><div className="field"><label>Template</label><select value={automation.visualTemplate} onChange={(event) => setAutomation((a) => ({ ...a, visualTemplate: event.target.value }))}><option value="nebula">Nebula orbit</option><option value="pulse">Pulse wave</option><option value="bars">Neon bars</option></select></div><div className="field"><label>Palette</label><select value={automation.visualPalette} onChange={(event) => setAutomation((a) => ({ ...a, visualPalette: event.target.value }))}>{Object.entries(PALETTES).map(([id, palette]) => <option key={id} value={id}>{palette.name}</option>)}</select></div></div></section>
      <button className="btn btn-primary settings-save-main" onClick={() => save('automation', automation, {}, 'Automation defaults save ho gaye.')} disabled={Boolean(busy)}>{busy === 'automation' ? <Spinner /> : <Check size={17} />}Automation settings save karein</button>
    </div><SettingsAside data={data} navigate={navigate} /></div>}

    {tab === 'guide' && <SetupGuide data={data} copyCallback={copyCallback} />}
  </div>;
}

function ConnectionBadge({ connected }) {
  return <span className={classNames('connection-badge', connected && 'connected')}>{connected ? <CheckCircle2 size={14} /> : <CircleAlert size={14} />}{connected ? 'Connected' : 'Setup needed'}</span>;
}

function SecretField({ label, name, value, configured, visible, onVisible, onChange, placeholder }) {
  return <div className="field"><div className="label-row"><label>{label}</label>{configured && <span className="saved-label"><LockKeyhole size={12} />Encrypted & saved</span>}</div><div className="secret-input"><KeyRound size={16} /><input type={visible ? 'text' : 'password'} value={value} onChange={(event) => onChange(name, event.target.value)} placeholder={configured ? 'Saved value replace karne ke liye naya enter karein' : placeholder} autoComplete="off" /><button onClick={onVisible} type="button" aria-label={visible ? 'Hide key' : 'Show key'}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></div>;
}

function SettingsAside({ data, navigate }) {
  return <aside className="settings-aside"><div className="side-card security-card"><ShieldCheck size={27} /><h3>Your keys stay server-side</h3><p>Secrets AES-256-GCM se encrypt hote hain. Browser ko sirf “connected” status milta hai, actual key nahi.</p><div><LockKeyhole size={15} /><span>Production mein APP_ACCESS_CODE aur TOKEN_ENCRYPTION_KEY set karna zaroori hai.</span></div></div><div className="side-card setup-summary"><span className="eyebrow">CONNECTION HEALTH</span>{[[data.secrets.geminiApiKey || data.secrets.openaiApiKey, 'AI writer'], [data.secrets.musicgptApiKey, 'Music API'], [data.youtube.connected, 'YouTube']].map(([done, label]) => <div key={label}><span className={classNames('health-dot', done && 'done')} />{label}<strong>{done ? 'Ready' : 'Pending'}</strong></div>)}<button className="btn btn-ghost btn-full" onClick={() => navigate('/create')}>Creator kholein<ArrowRight size={15} /></button></div></aside>;
}

function SetupGuide({ data, copyCallback }) {
  return <div className="guide-layout"><section className="settings-card guide-card"><div className="settings-card-heading"><span className="form-icon lime"><FileKey2 size={21} /></span><div><h2>Personal setup guide</h2><p>Ek baar setup, phir har release automated.</p></div></div><div className="guide-steps"><GuideStep number="1" title="AI writer key banayein" text="Google AI Studio mein Gemini API key banayein (ya OpenAI API key). Connections → AI writer mein key aur available model save karein." /><GuideStep number="2" title="MusicGPT API activate karein" text="MusicGPT API dashboard se key aur credits activate karein. Normal website subscription mein API credits included na bhi hon—dashboard par plan verify karein." /><GuideStep number="3" title="Google Cloud project ready karein" text="YouTube Data API v3 enable karein. OAuth consent screen configure karke Web application type ka OAuth Client banayein." /><GuideStep number="4" title="Redirect URI aur channel connect karein" text="Neeche wali URI Authorized redirect URIs mein add karein. Phir Connections → YouTube → Save & connect par Google account select karein." /><GuideStep number="5" title="Pehle private test, phir full-auto" text="Ek short test release private upload karke audio/video/metadata check karein. Uske baad default public/scheduled automation on karein." /></div><div className="field"><label>Aapka OAuth redirect URI</label><div className="copy-field"><code>{data.capabilities.youtubeCallback}</code><button onClick={copyCallback}><Copy size={16} /></button></div></div><InlineNotice tone="warning" title="Google API compliance">YouTube uploads ke liye app verification/API audit rules apply ho sakte hain. Agar uploads private restricted hon, public automation se pehle Google Cloud project ka compliance review complete karein.</InlineNotice></section><aside className="guide-aside"><div className="side-card"><span className="eyebrow">DEPLOYMENT CHECKLIST</span>{['Server ka PUBLIC_URL HTTPS par set hai', 'APP_ACCESS_CODE set hai', 'TOKEN_ENCRYPTION_KEY set hai', 'YouTube Data API v3 enabled hai', 'Correct redirect URI whitelisted hai', 'AI + Music API credits available hain'].map((item) => <div className="checklist-item" key={item}><Check size={14} />{item}</div>)}</div><div className="side-card"><span className="eyebrow">ANDROID APP</span><h3>Same studio, native shell</h3><p>Project mein Capacitor Android app included hai. Cloud server deploy karke VITE_API_URL set karein, phir Android Studio se APK build karein.</p></div></aside></div>;
}

function GuideStep({ number, title, text }) {
  return <div className="guide-step"><span>{number}</span><div><h3>{title}</h3><p>{text}</p></div></div>;
}
