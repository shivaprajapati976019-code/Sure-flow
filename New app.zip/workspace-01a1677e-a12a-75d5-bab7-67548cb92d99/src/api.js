import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';

const BUILD_API_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/+$/, '');
const SERVER_KEY = 'surflow_server_url';
const TOKEN_KEY = 'surflow_session';
export const isNative = Capacitor.isNativePlatform();

export function getApiBase() {
  const runtime = isNative ? (localStorage.getItem(SERVER_KEY) || '') : '';
  return (runtime || BUILD_API_BASE).replace(/\/+$/, '');
}
export function setApiBase(value) {
  const url = new URL(String(value || '').trim());
  const localHost = ['localhost', '127.0.0.1', '10.0.2.2'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && localHost)) {
    throw new Error('Secure HTTPS server URL enter karein, jaise https://surflow-api.onrender.com');
  }
  if (url.pathname !== '/' || url.search || url.hash) throw new Error('Server ka root URL enter karein, API path ke bina.');
  const normalized = url.origin.replace(/\/+$/, '');
  localStorage.setItem(SERVER_KEY, normalized);
  return normalized;
}
export const hasServerConfig = () => !isNative || Boolean(getApiBase());
export const getToken = () => localStorage.getItem(TOKEN_KEY) || '';
export const setToken = (token) => token ? localStorage.setItem(TOKEN_KEY, token) : localStorage.removeItem(TOKEN_KEY);

export async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  const token = getToken();
  if (token) headers.set('Authorization', `Bearer ${token}`);
  let body = options.body;
  if (body && !(body instanceof FormData) && typeof body !== 'string') {
    headers.set('Content-Type', 'application/json');
    body = JSON.stringify(body);
  }
  const response = await fetch(`${getApiBase()}${path}`, { ...options, headers, body });
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || 'Invalid server response' }; }
  if (!response.ok) {
    if (response.status === 401) window.dispatchEvent(new CustomEvent('surflow:unauthorized'));
    const error = new Error(data.error || `Request failed (${response.status})`);
    error.code = data.code || 'REQUEST_FAILED';
    error.status = response.status;
    error.details = data.details;
    throw error;
  }
  return data;
}

export function uploadFile(kind, file, onProgress = () => {}) {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open('POST', `${getApiBase()}/api/uploads/${kind}`);
    const token = getToken();
    if (token) request.setRequestHeader('Authorization', `Bearer ${token}`);
    request.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    request.onerror = () => reject(new Error('Upload ke dauraan network error hua.'));
    request.onload = () => {
      let data;
      try { data = JSON.parse(request.responseText); } catch { data = {}; }
      if (request.status >= 200 && request.status < 300) resolve(data);
      else {
        const error = new Error(data.error || 'File upload fail hua.');
        error.code = data.code;
        reject(error);
      }
    };
    const form = new FormData();
    form.append('file', file);
    request.send(form);
  });
}

export const mediaUrl = (path) => path ? `${getApiBase()}${path}` : '';
export async function openExternal(url) {
  if (isNative) await Browser.open({ url, presentationStyle: 'popover' });
  else window.open(url, '_blank', 'noopener,noreferrer');
}
