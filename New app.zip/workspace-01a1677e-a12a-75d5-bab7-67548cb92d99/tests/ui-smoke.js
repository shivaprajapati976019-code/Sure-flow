import { chromium } from 'playwright';
import fs from 'node:fs';

fs.mkdirSync('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true });
const errors = [];
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
page.on('pageerror', (error) => errors.push(`page: ${error.message}`));

await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });
await page.screenshot({ path: 'artifacts/dashboard-desktop.png', fullPage: true });
const desktopOverflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);

await page.getByRole('button', { name: /Naya song/i }).first().click();
await page.waitForTimeout(400);
await page.screenshot({ path: 'artifacts/create-desktop.png', fullPage: true });

await page.goto('http://127.0.0.1:3000/#/settings', { waitUntil: 'networkidle' });
await page.waitForTimeout(450);
await page.screenshot({ path: 'artifacts/settings-desktop.png', fullPage: true });

const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 });
mobile.on('console', (message) => { if (message.type() === 'error') errors.push(`mobile console: ${message.text()}`); });
mobile.on('pageerror', (error) => errors.push(`mobile page: ${error.message}`));
await mobile.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });
await mobile.screenshot({ path: 'artifacts/dashboard-mobile.png', fullPage: true });
const mobileOverflow = await mobile.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);

const jobLink = mobile.locator('.job-card').first();
if (await jobLink.count()) {
  await jobLink.click();
  await mobile.waitForTimeout(600);
  await mobile.screenshot({ path: 'artifacts/job-mobile.png', fullPage: true });
}

console.log(JSON.stringify({ desktopOverflow, mobileOverflow, errors }, null, 2));
await browser.close();
if (desktopOverflow || mobileOverflow || errors.length) process.exitCode = 1;
