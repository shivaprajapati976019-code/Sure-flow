import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from './config.js';

const SECRETS_FILE = path.join(DATA_DIR, 'secrets.json');
const KEY_FILE = path.join(DATA_DIR, '.master-key');

function masterKey() {
  if (process.env.TOKEN_ENCRYPTION_KEY) {
    return crypto.createHash('sha256').update(process.env.TOKEN_ENCRYPTION_KEY).digest();
  }
  if (!fs.existsSync(KEY_FILE)) {
    fs.writeFileSync(KEY_FILE, crypto.randomBytes(32).toString('base64'), { mode: 0o600 });
  }
  return Buffer.from(fs.readFileSync(KEY_FILE, 'utf8').trim(), 'base64');
}

function readAll() {
  try { return JSON.parse(fs.readFileSync(SECRETS_FILE, 'utf8')); } catch { return {}; }
}

function writeAll(data) {
  const temp = `${SECRETS_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(temp, SECRETS_FILE);
}

export function setSecret(name, value) {
  if (value === undefined || value === null || String(value).trim() === '') return;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', masterKey(), iv);
  const encrypted = Buffer.concat([cipher.update(String(value).trim(), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  const all = readAll();
  all[name] = ['v1', iv.toString('base64url'), tag.toString('base64url'), encrypted.toString('base64url')].join('.');
  writeAll(all);
}

export function getSecret(name) {
  const stored = readAll()[name];
  if (!stored) return '';
  try {
    const [version, ivText, tagText, payload] = stored.split('.');
    if (version !== 'v1') return '';
    const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey(), Buffer.from(ivText, 'base64url'));
    decipher.setAuthTag(Buffer.from(tagText, 'base64url'));
    return Buffer.concat([decipher.update(Buffer.from(payload, 'base64url')), decipher.final()]).toString('utf8');
  } catch {
    return '';
  }
}

export function deleteSecret(name) {
  const all = readAll();
  delete all[name];
  writeAll(all);
}

export function secretStatus() {
  const all = readAll();
  return Object.fromEntries(Object.keys(all).map((key) => [key, Boolean(getSecret(key))]));
}

export const SECRET_FIELDS = [
  'geminiApiKey', 'openaiApiKey', 'musicgptApiKey',
  'googleClientId', 'googleClientSecret', 'googleRefreshToken', 'googleAccessToken',
];
