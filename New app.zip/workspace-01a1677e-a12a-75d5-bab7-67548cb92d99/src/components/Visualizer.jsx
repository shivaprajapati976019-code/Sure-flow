import React, { useEffect, useRef } from 'react';
import { PALETTES } from '../data.js';

export default function Visualizer({ template = 'nebula', paletteName = 'lime', title = 'Aapka agla gaana', artist = 'Original release', audioUrl = '', compact = false }) {
  const canvasRef = useRef(null);
  const audioRef = useRef(null);
  const analyserRef = useRef(null);
  const audioContextRef = useRef(null);
  const sourceRef = useRef(null);

  async function initAudio() {
    try {
      if (!audioContextRef.current) {
        const Context = window.AudioContext || window.webkitAudioContext;
        if (!Context) return;
        const context = new Context();
        const analyser = context.createAnalyser();
        analyser.fftSize = 256;
        analyser.smoothingTimeConstant = 0.82;
        const source = context.createMediaElementSource(audioRef.current);
        source.connect(analyser);
        analyser.connect(context.destination);
        audioContextRef.current = context;
        analyserRef.current = analyser;
        sourceRef.current = source;
      }
      if (audioContextRef.current.state === 'suspended') await audioContextRef.current.resume();
    } catch {
      // Simulated preview remains available if Web Audio is restricted.
    }
  }

  useEffect(() => () => {
    audioContextRef.current?.close().catch(() => {});
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const palette = PALETTES[paletteName] || PALETTES.lime;
    let frame;
    let width = 0;
    let height = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const frequency = new Uint8Array(128);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();

    const sample = (index, time, count) => {
      if (analyserRef.current && audioRef.current && !audioRef.current.paused) {
        return frequency[Math.floor((index / count) * Math.min(96, frequency.length))] / 255;
      }
      return 0.20 + Math.abs(Math.sin(index * 0.71 + time * 1.65) * Math.cos(index * 0.17 - time * 0.8)) * 0.62;
    };

    const drawText = () => {
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,.45)';
      ctx.shadowBlur = 12;
      ctx.fillStyle = '#ffffff';
      const size = Math.max(17, Math.min(30, width / 24));
      ctx.font = `650 ${size}px system-ui, sans-serif`;
      const clipped = title.length > 44 ? `${title.slice(0, 43)}…` : title;
      ctx.fillText(clipped, width / 2, compact ? 33 : 43, width * 0.84);
      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(255,255,255,.64)';
      ctx.font = `500 ${Math.max(10, size * 0.43)}px system-ui, sans-serif`;
      ctx.fillText(artist || 'Original release', width / 2, compact ? 51 : 69, width * 0.8);
    };

    const draw = (milliseconds) => {
      const time = milliseconds / 1000;
      if (analyserRef.current && audioRef.current && !audioRef.current.paused) analyserRef.current.getByteFrequencyData(frequency);
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, palette.bg0);
      gradient.addColorStop(1, palette.bg1);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      const glow = ctx.createRadialGradient(width * 0.72, height * 0.65, 0, width * 0.72, height * 0.65, width * 0.55);
      glow.addColorStop(0, `${palette.second}30`);
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);

      for (let i = 0; i < 35; i += 1) {
        const x = ((i * 83.7) % 100) / 100 * width;
        const y = ((i * 47.3 + time * (i % 3 + 1)) % 100) / 100 * height;
        ctx.globalAlpha = 0.12 + (i % 5) * 0.035;
        ctx.fillStyle = i % 2 ? palette.first : '#ffffff';
        ctx.beginPath();
        ctx.arc(x, y, 0.6 + (i % 3) * 0.45, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      if (template === 'bars') {
        const count = Math.max(34, Math.floor(width / 13));
        const gap = 3;
        const barWidth = Math.max(2, (width - 70 - gap * count) / count);
        const base = height * 0.88;
        for (let i = 0; i < count; i += 1) {
          const value = sample(i, time, count);
          const barHeight = 12 + value * height * 0.52;
          const x = 35 + i * (barWidth + gap);
          const barGradient = ctx.createLinearGradient(0, base - barHeight, 0, base);
          barGradient.addColorStop(0, i % 3 ? palette.first : palette.second);
          barGradient.addColorStop(1, `${palette.second}55`);
          ctx.fillStyle = barGradient;
          ctx.shadowColor = palette.first;
          ctx.shadowBlur = value * 12;
          ctx.beginPath();
          ctx.roundRect(x, base - barHeight, barWidth, barHeight, barWidth / 2);
          ctx.fill();
          ctx.globalAlpha = 0.15;
          ctx.fillRect(x, base + 5, barWidth, barHeight * 0.24);
          ctx.globalAlpha = 1;
        }
      } else if (template === 'pulse') {
        const centerY = height * 0.59;
        for (let layer = 0; layer < 3; layer += 1) {
          ctx.beginPath();
          for (let x = 0; x <= width; x += 3) {
            const index = Math.floor((x / width) * 90);
            const value = sample(index, time + layer * 0.15, 90);
            const envelope = Math.sin((x / width) * Math.PI);
            const y = centerY + Math.sin(x * 0.038 + time * (2.2 + layer * 0.3)) * value * height * 0.29 * envelope + (layer - 1) * 15;
            if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.strokeStyle = layer === 1 ? palette.first : `${palette.second}${layer === 0 ? '80' : '45'}`;
          ctx.lineWidth = layer === 1 ? 2.5 : 1.3;
          ctx.shadowColor = layer === 1 ? palette.first : palette.second;
          ctx.shadowBlur = layer === 1 ? 20 : 10;
          ctx.stroke();
        }
      } else {
        const cx = width / 2;
        const cy = height * 0.60;
        const radius = Math.min(width, height) * 0.20;
        const count = 72;
        ctx.lineCap = 'round';
        for (let i = 0; i < count; i += 1) {
          const angle = (i / count) * Math.PI * 2 - Math.PI / 2;
          const value = sample(i, time, count);
          const inner = radius + Math.sin(time + i) * 2;
          const outer = inner + 8 + value * height * 0.20;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
          ctx.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
          ctx.strokeStyle = i % 4 === 0 ? palette.second : palette.first;
          ctx.globalAlpha = 0.45 + value * 0.55;
          ctx.lineWidth = Math.max(1.4, width / 330);
          ctx.shadowColor = ctx.strokeStyle;
          ctx.shadowBlur = 10;
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
        const orb = ctx.createRadialGradient(cx - radius * 0.2, cy - radius * 0.25, 0, cx, cy, radius * 0.93);
        orb.addColorStop(0, `${palette.first}70`);
        orb.addColorStop(0.45, `${palette.second}30`);
        orb.addColorStop(1, 'rgba(4,6,8,.86)');
        ctx.fillStyle = orb;
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.91, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.16)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
      drawText();
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [template, paletteName, title, artist, compact]);

  return <div className={`visualizer-wrap ${compact ? 'visualizer-compact' : ''}`}>
    <canvas ref={canvasRef} className="visualizer-canvas" aria-label={`${template} audio visualizer preview`} />
    {audioUrl && <audio ref={audioRef} key={audioUrl} className="visualizer-audio" src={audioUrl} controls preload="metadata" crossOrigin="anonymous" onPlay={initAudio} />}
  </div>;
}
