import React, { useMemo, useState } from 'react';
import { Library as LibraryIcon, Plus, Search, SlidersHorizontal } from 'lucide-react';
import { EmptyState, JobArt, StatusPill } from '../components/UI.jsx';
import { ACTIVE_STATUSES } from '../data.js';
import { classNames, formatDate } from '../utils.js';

const FILTERS = [['all', 'Sab'], ['active', 'In progress'], ['ready', 'Ready'], ['published', 'Published'], ['scheduled', 'Scheduled'], ['failed', 'Action needed']];

export default function Library({ jobs, navigate, onDemo }) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const filtered = useMemo(() => jobs.filter((job) => {
    const matchesSearch = `${job.title} ${job.input?.topic} ${job.input?.genre}`.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (filter === 'all') return true;
    if (filter === 'active') return ACTIVE_STATUSES.includes(job.status);
    if (filter === 'failed') return ['failed', 'action_required'].includes(job.status);
    return job.status === filter;
  }), [jobs, filter, search]);

  return <div className="page library-page">
    <div className="page-heading"><div><span className="eyebrow">YOUR CATALOG</span><h1>Release library</h1><p>Har song, video aur YouTube status ek jagah.</p></div><button className="btn btn-primary" onClick={() => navigate('/create')}><Plus size={18} />Naya song</button></div>
    <div className="library-tools"><div className="search-box"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Title, idea ya genre search karein…" /></div><div className="filter-scroll">{FILTERS.map(([id, label]) => <button key={id} className={classNames(filter === id && 'selected')} onClick={() => setFilter(id)}>{label}{id === 'all' && <span>{jobs.length}</span>}</button>)}</div></div>
    {jobs.length === 0 ? <EmptyState onCreate={() => navigate('/create')} onDemo={onDemo} /> : filtered.length === 0 ? <div className="empty-state compact"><span className="empty-icon"><SlidersHorizontal size={25} /></span><h3>Is filter mein koi release nahi</h3><p>Search ya filter badal kar dekhein.</p><button className="btn btn-ghost" onClick={() => { setFilter('all'); setSearch(''); }}>Filters clear karein</button></div> : <div className="library-grid">{filtered.map((job) => <button className="library-card" key={job.id} onClick={() => navigate(`/jobs/${job.id}`)}><JobArt job={job} large /><div className="library-card-body"><div><StatusPill status={job.status} />{job.demo && <span className="demo-tag">DEMO</span>}</div><h3>{job.title}</h3><p>{job.input?.genre} • {job.input?.language}</p><footer><time>{formatDate(job.createdAt, true)}</time><span>{job.youtube?.videoId ? 'YouTube ↗' : job.videoUrl ? 'MP4 ready' : `${job.progress || 0}%`}</span></footer></div></button>)}</div>}
    {jobs.length > 0 && <div className="library-footnote"><LibraryIcon size={15} />Latest 100 projects is personal workspace mein save hote hain.</div>}
  </div>;
}
