import fs from 'node:fs';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { AppError } from './errors.js';

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
export const asString = (value, max = 5000) => String(value ?? '').trim().slice(0, max);
export const asBool = (value, fallback = false) => typeof value === 'boolean' ? value : fallback;

export function safeExtension(filename, allowed, fallback) {
  const ext = path.extname(String(filename || '')).toLowerCase().replace(/[^a-z0-9.]/g, '');
  return allowed.includes(ext) ? ext : fallback;
}

export async function fetchChecked(url, options = {}, label = 'External service') {
  let response;
  try {
    response = await fetch(url, { ...options, signal: options.signal || AbortSignal.timeout(60_000) });
  } catch (error) {
    if (error?.name === 'TimeoutError' || error?.name === 'AbortError') {
      throw new AppError(`${label} ne time par response nahi diya.`, 504, 'UPSTREAM_TIMEOUT');
    }
    throw new AppError(`${label} se connect nahi ho paya. Internet aur API configuration check karein.`, 502, 'UPSTREAM_UNREACHABLE');
  }
  const text = await response.text();
  let body;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!response.ok) {
    const upstreamMessage = body?.error?.message || body?.message || body?.error_description || body?.error || `HTTP ${response.status}`;
    throw new AppError(`${label}: ${String(upstreamMessage).slice(0, 500)}`, response.status >= 500 ? 502 : 400, 'UPSTREAM_ERROR', { status: response.status });
  }
  return body;
}

export async function downloadToFile(url, destination, maxBytes = 250 * 1024 * 1024) {
  const parsed = new URL(url);
  if (!['https:', 'http:'].includes(parsed.protocol)) throw new AppError('Audio URL safe nahi hai.', 400, 'UNSAFE_URL');
  const response = await fetch(parsed, { signal: AbortSignal.timeout(120_000) });
  if (!response.ok) throw new AppError('Generated audio download nahi ho paya.', 502, 'AUDIO_DOWNLOAD_FAILED');
  const length = Number(response.headers.get('content-length') || 0);
  if (length > maxBytes) throw new AppError('Audio file bahut badi hai.', 413, 'FILE_TOO_LARGE');
  if (!response.body) throw new AppError('Audio response khaali hai.', 502, 'EMPTY_AUDIO');
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  let bytes = 0;
  const counter = async function* (source) {
    for await (const chunk of source) {
      bytes += chunk.length;
      if (bytes > maxBytes) throw new AppError('Audio file bahut badi hai.', 413, 'FILE_TOO_LARGE');
      yield chunk;
    }
  };
  await pipeline(Readable.fromWeb(response.body), counter, fs.createWriteStream(destination));
  return destination;
}

export function parseJsonPayload(value) {
  if (typeof value !== 'string') return value;
  const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  try { return JSON.parse(clean); } catch {
    const start = clean.indexOf('{');
    const end = clean.lastIndexOf('}');
    if (start >= 0 && end > start) return JSON.parse(clean.slice(start, end + 1));
    throw new AppError('AI ne valid JSON response nahi diya. Dobara try karein.', 502, 'AI_INVALID_JSON');
  }
}

export function toPublicJob(job) {
  if (!job) return null;
  const { audioPath, videoPath, ...safe } = job;
  return {
    ...safe,
    audioUrl: audioPath ? `/media/${job.id}/audio${path.extname(audioPath) || '.mp3'}` : null,
    videoUrl: videoPath ? `/media/${job.id}/video.mp4` : null,
  };
}
