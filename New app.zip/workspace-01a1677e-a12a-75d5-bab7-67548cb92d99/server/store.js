import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from './config.js';
import { secretStatus } from './secrets.js';

const DB_FILE = path.join(DATA_DIR, 'store.json');

const DEFAULT_SETTINGS = {
  textProvider: 'gemini',
  geminiModel: 'gemini-3.6-flash',
  openaiModel: 'gpt-4.1-mini',
  musicModel: 'v7',
  artistName: '',
  autoPublish: true,
  privacy: 'public',
  madeForKids: false,
  containsSyntheticMedia: true,
  dailyLimit: 5,
  visualTemplate: 'nebula',
  visualPalette: 'lime',
};

const DEFAULT_DB = {
  settings: DEFAULT_SETTINGS,
  youtube: { connected: false, channelId: '', channelTitle: '', connectedAt: null, tokenExpiry: 0 },
  jobs: [],
};

function load() {
  try {
    const saved = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return {
      ...DEFAULT_DB,
      ...saved,
      settings: { ...DEFAULT_SETTINGS, ...saved.settings },
      youtube: { ...DEFAULT_DB.youtube, ...saved.youtube },
      jobs: Array.isArray(saved.jobs) ? saved.jobs : [],
    };
  } catch {
    return structuredClone(DEFAULT_DB);
  }
}

let db = load();

function persist() {
  const temp = `${DB_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(temp, DB_FILE);
}

export const getSettings = () => ({ ...db.settings });
export function updateSettings(patch) {
  const allowed = Object.keys(DEFAULT_SETTINGS);
  for (const key of Object.keys(patch)) {
    if (!allowed.includes(key)) continue;
    db.settings[key] = patch[key];
  }
  db.settings.dailyLimit = Math.max(1, Math.min(20, Number(db.settings.dailyLimit) || 5));
  if (!['public', 'private', 'unlisted'].includes(db.settings.privacy)) db.settings.privacy = 'private';
  if (!['gemini', 'openai'].includes(db.settings.textProvider)) db.settings.textProvider = 'gemini';
  if (!['nebula', 'pulse', 'bars'].includes(db.settings.visualTemplate)) db.settings.visualTemplate = 'nebula';
  persist();
  return getSettings();
}
export const getYoutube = () => ({ ...db.youtube });
export function updateYoutube(patch) {
  db.youtube = { ...db.youtube, ...patch };
  persist();
  return getYoutube();
}
export const listJobs = () => [...db.jobs].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
export const getJob = (id) => db.jobs.find((job) => job.id === id);
export function putJob(job) {
  const index = db.jobs.findIndex((item) => item.id === job.id);
  if (index >= 0) db.jobs[index] = job;
  else db.jobs.push(job);
  if (db.jobs.length > 100) db.jobs = db.jobs.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 100);
  persist();
  return job;
}
export function patchJob(id, patch) {
  const job = getJob(id);
  if (!job) return null;
  Object.assign(job, patch, { updatedAt: new Date().toISOString() });
  putJob(job);
  return job;
}
export function publicBootstrap() {
  return {
    settings: getSettings(),
    youtube: { ...getYoutube(), tokenExpiry: undefined },
    secrets: secretStatus(),
    jobs: listJobs(),
    limits: { dailyUploadsMax: 20, jobsStored: 100 },
  };
}
