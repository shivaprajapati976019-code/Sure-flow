# SurFlow

**Idea → lyrics/style → AI music → audio-reactive video → YouTube upload.** Android aur web ke liye personal music-release automation studio.

## Kya-kya included hai

- **Android APK + responsive web app** — ek hi studio, mobile bottom navigation aur desktop dashboard.
- **Full-auto ya review mode** — ek click automation, ya 4-step editor: Idea, Sound, Video, Publish.
- **Gemini / OpenAI writer** — original lyrics, production style, title, description, tags aur hashtags.
- **MusicGPT Public API** — generation, status polling, audio download aur retry-safe pipeline.
- **Audio Import** — Suno/MusicGPT website se downloaded MP3/WAV/M4A/AAC/OGG/FLAC attach karein.
- **Built-in renderer** — Nebula, Pulse aur Neon Bars; 4 palettes; actual audio-reactive **1280×720, 30fps H.264 + AAC MP4**; no forced watermark.
- **External video handoff** — Specterr/MusicVid se exported MP4 import karke baaki workflow automate karein.
- **YouTube OAuth** — password ke bina channel connection; chunked resumable upload; Public, Unlisted, Private aur scheduled publishing.
- **Safety controls** — rights confirmation, daily upload limit, made-for-kids aur AI/synthetic-media disclosure.
- **Secure personal workspace** — optional access code; API keys/tokens AES-256-GCM encrypted server storage mein.
- **Free local demo** — bina paid API key ke 12-second original instrumental aur real MP4 render.

> **Important:** Sirf Suno/MusicGPT/Gemini ke website login se full-auto nahi chalega. Official API keys aur applicable credits chahiye. Specterr ke liye manual MP4 export/import workflow hai. Yeh personal, single-owner workspace hai—multi-user SaaS nahi.

## Sabse pehle: free demo

```bash
npm install
npm run build
npm start
```

Browser mein `http://localhost:3000` kholein → **Free demo dekho**. Isme koi external AI call ya YouTube upload nahi hota.

Development mode:

```bash
npm run dev
```

Web: `http://localhost:5173` • API: `http://localhost:3000`

## Android app

### Ready APK

`SurFlow-debug.apk` ko Android phone par copy karke install karein. Android “Install unknown apps” permission maang sakta hai. Yeh **testing debug build** hai, Play Store release build nahi.

1. SurFlow kholein.
2. Apne deployed backend ka **HTTPS root URL** enter karein, jaise `https://surflow-api.onrender.com`.
3. Agar server par `APP_ACCESS_CODE` set hai to use enter karein.
4. Settings mein API keys aur YouTube channel connect karein.

Server URL device par save hota hai; backend badalne par URL change kiya ja sakta hai. API keys Android app mein store nahi hoti.

### Android source se build

Requirements: Node 20.19+, current Android Studio/Android SDK aur supported JDK.

```bash
npm install
npm run android:sync
npm run android:open
```

Android Studio → **Build → Build APK(s)**. Ya supported local SDK setup mein:

```bash
cd android
./gradlew assembleDebug
```

Play Store ke liye Android Studio → **Generate Signed Bundle / APK → Android App Bundle** use karein aur apni private release key secure rakhein.

## Backend deploy karna

Docker sabse straightforward option hai. Persistent disk zaroori hai, warna jobs/tokens/media restart par lose ho sakte hain.

```bash
cp .env.example .env
# .env mein production values bharein

docker build -t surflow .
docker run -p 3000:3000 --env-file .env -v surflow-data:/app/data surflow
```

Ya `docker compose up -d --build`.

### Required production environment

```env
PUBLIC_URL=https://your-public-domain.com
WEB_APP_URL=https://your-public-domain.com
APP_ACCESS_CODE=ek-lamba-random-access-code
TOKEN_ENCRYPTION_KEY=ek-dusra-lamba-random-secret
DATA_DIR=/app/data
```

`TOKEN_ENCRYPTION_KEY` generate karne ka example:

```bash
openssl rand -hex 32
```

**PUBLIC_URL externally accessible HTTPS hona chahiye.** Google OAuth callback aur Android dono isi URL ka use karte hain. `APP_ACCESS_CODE` ke bana public internet par deploy na karein.

## API connections

### 1. Gemini ya OpenAI

App → **Settings → Connections → AI writer**:

- Gemini: [Google AI Studio API key](https://aistudio.google.com/apikey)
- OpenAI: [API keys](https://platform.openai.com/api-keys)

Key app mein paste karke save karein, ya `.env` mein `GEMINI_API_KEY` / `OPENAI_API_KEY` use karein. Model field mein apne account ka available stable JSON-output model rakhein.

### 2. MusicGPT

[MusicGPT API dashboard](https://musicgpt.com/api-dashboard) se API key/credits activate karein → Settings → Music generation mein save karein. Normal website plan aur API billing alag ho sakte hain.

Official docs:

- `POST /api/public/v2/MusicAI`
- `GET /api/public/v1/byId`
- https://docs.musicgpt.com/api-documentation/

Suno website se banaya audio ho to API key ke bina **Creator → Sound → Audio Import** use kar sakte hain. Manual editor se lyrics/style paste kar sakte hain.

### 3. YouTube / Google Cloud

1. [Google Cloud Console](https://console.cloud.google.com/) mein project banayein.
2. **YouTube Data API v3** enable karein.
3. OAuth consent screen configure karein; testing mein apna Google email test user banayein.
4. **Web application** type OAuth Client banayein.
5. Authorized redirect URI mein exactly yeh add karein:

   ```text
   https://your-public-domain.com/api/auth/youtube/callback
   ```

6. Client ID/Secret SurFlow Settings mein save karein → **Save & connect YouTube**.
7. Pehla test **Private** upload karein, phir Public/Scheduled automation on karein.

App `youtube.upload` aur `youtube.readonly` scopes maangta hai. Google ki current verification/API compliance requirements check karein; kuch unaudited projects par API uploads private restricted reh sakte hain. Scheduled upload private status + `publishAt` ke saath bheja jaata hai.

Official reference: https://developers.google.com/youtube/v3/docs/videos/insert

## Recommended first real release

1. Settings mein AI writer, MusicGPT aur YouTube connect karein.
2. Automation mein artist name aur daily limit set karein.
3. Creator mein idea likhein → **Step-by-step review** chunein.
4. Lyrics/style aur metadata edit karein.
5. Visibility **Private** rakhein → Release shuru karein.
6. Job detail par actual video play/download karke verify karein.
7. Sab sahi ho to next release Public ya Scheduled karein.

Retry karne par saved audio/video/metadata reuse hote hain, taaki avoidable API cost na lage. Server ke beech mein band hone par job ko **Retry** karein.

## Commands

```bash
npm run dev             # web + API development
npm run build           # production web bundle
npm start               # production server on :3000
npm test                # core validation tests
npm run test:ui         # Playwright UI smoke; server running hona chahiye
npm run test:manual     # manual Hindi creative + audio import → ready MP4; server chahiye
npm run android:sync    # web bundle → native Android project
npm run android:build   # sync + debug APK (local SDK/JDK required)
npm run android:open    # Android Studio
```

## Project map

```text
src/                  React Android + web UI
server/ai.js          Gemini/OpenAI structured writing
server/music.js       MusicGPT generation + polling
server/render.js      FFmpeg audio-reactive MP4 renderer
server/youtube.js     OAuth + chunked resumable upload
server/pipeline.js    Retry-safe release state machine
android/              Capacitor native Android project
assets/fonts/         Bundled Devanagari font for video titles
scripts/              Native icon/splash generator
tests/                Core + browser smoke tests
```

## Security & operating notes

- YouTube password kabhi enter na karein; sirf Google OAuth screen use karein.
- Public deployment par HTTPS, access code, persistent disk aur strong encryption key use karein.
- `data/` mein jobs, encrypted secrets aur generated media hote hain—isse private rakhein aur backup karein.
- AI provider ke commercial-use terms aur YouTube content policies aap khud verify karein.
- Ek server par ek personal owner/workspace recommended hai. Multi-user production SaaS ke liye per-user auth, database, queue aur object storage add karna hoga.
