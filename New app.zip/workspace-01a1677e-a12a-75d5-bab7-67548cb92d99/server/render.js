import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import ffmpegPath from 'ffmpeg-static';
import { ROOT_DIR } from './config.js';
import { AppError } from './errors.js';

const PALETTES = {
  lime: { first: '0xC6F56F', second: '0x8A6CFF', bg0: '0x0A0D0B', bg1: '0x17251B' },
  violet: { first: '0xB79CFF', second: '0xFF7AC8', bg0: '0x0D0A14', bg1: '0x25153B' },
  sunset: { first: '0xFFB65C', second: '0xFF667D', bg0: '0x140C09', bg1: '0x351A16' },
  ocean: { first: '0x62E7F2', second: '0x5478FF', bg0: '0x071014', bg1: '0x0B2933' },
};

function xmlText(value, max = 90) {
  return String(value || '').trim().slice(0, max)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/\r?\n/g, ' ');
}

async function renderTitleOverlay(jobDir, title, artist) {
  process.env.FONTCONFIG_FILE = path.join(ROOT_DIR, 'assets', 'fonts.conf');
  const { default: sharp } = await import('sharp');
  const safeTitle = xmlText(title || 'Original release', 80);
  const safeArtist = xmlText(artist || 'Original release', 90);
  const isDevanagari = /[\u0900-\u097F]/.test(`${title}${artist}`);
  const font = isDevanagari ? 'Noto Sans Devanagari' : 'DejaVu Sans';
  const length = String(title || '').length;
  const titleSize = length > 60 ? 32 : length > 42 ? 40 : length > 28 ? 46 : 52;
  const fit = length > 60 ? 'textLength="1100" lengthAdjust="spacingAndGlyphs"' : '';
  const svg = `<svg width="1280" height="720" xmlns="http://www.w3.org/2000/svg">
    <style>
      .title { font-family: '${font}'; font-size: ${titleSize}px; font-weight: 700; }
      .artist { font-family: '${font}'; font-size: 23px; font-weight: 400; letter-spacing: 1px; }
    </style>
    <text x="640" y="91" text-anchor="middle" class="title" fill="#000000" opacity="0.55" ${fit}>${safeTitle}</text>
    <text x="640" y="88" text-anchor="middle" class="title" fill="#ffffff" ${fit}>${safeTitle}</text>
    <text x="640" y="139" text-anchor="middle" class="artist" fill="#d8d8d8">${safeArtist}</text>
  </svg>`;
  const overlayPath = path.join(jobDir, 'titles.png');
  await sharp(Buffer.from(svg)).png().toFile(overlayPath);
  return overlayPath;
}

function timeToSeconds(text) {
  const parts = text.split(':').map(Number);
  return parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : 0;
}

function runFfmpeg(args, { onProgress = () => {}, progressRange = [0, 100] } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, ['-hide_banner', '-y', ...args], { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    let duration = 0;
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      stderr = `${stderr}${text}`.slice(-40_000);
      const durationMatch = stderr.match(/Duration:\s*(\d{2}:\d{2}:\d{2}(?:\.\d+)?)/);
      if (durationMatch) duration = timeToSeconds(durationMatch[1]);
      const times = [...stderr.matchAll(/time=(\d{2}:\d{2}:\d{2}(?:\.\d+)?)/g)];
      if (duration && times.length) {
        const current = timeToSeconds(times.at(-1)[1]);
        const ratio = Math.max(0, Math.min(1, current / duration));
        onProgress(Math.round(progressRange[0] + ratio * (progressRange[1] - progressRange[0])));
      }
    });
    child.on('error', (error) => reject(new AppError(`Video renderer start nahi hua: ${error.message}`, 500, 'FFMPEG_START_FAILED')));
    child.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new AppError(`Video render fail hua: ${stderr.split('\n').filter(Boolean).slice(-4).join(' ').slice(0, 700)}`, 500, 'FFMPEG_RENDER_FAILED'));
    });
  });
}

export async function renderVideo({ audioPath, jobDir, title, artist, template = 'nebula', paletteName = 'lime', onProgress = () => {} }) {
  if (!ffmpegPath) throw new AppError('FFmpeg available nahi hai. Server setup check karein.', 500, 'FFMPEG_MISSING');
  const palette = PALETTES[paletteName] || PALETTES.lime;
  const overlayPath = await renderTitleOverlay(jobDir, title, artist);
  const outputPath = path.join(jobDir, 'video.mp4');
  let graph;

  if (template === 'bars') {
    graph = `gradients=s=1280x720:r=30:c0=${palette.bg0}:c1=${palette.bg1}:x0=0:y0=0:x1=1280:y1=720:type=linear[bg];[0:a]showfreqs=s=1280x720:mode=bar:cmode=combined:colors=${palette.first}|${palette.second}:ascale=sqrt:fscale=log:r=30[freq];[freq]colorkey=0x000000:0.10:0.08[fg];[bg][fg]overlay=0:0:format=auto,format=rgba[base];[1:v]format=rgba[text];[base][text]overlay=0:0:format=auto:shortest=1,format=yuv420p[out]`;
  } else if (template === 'pulse') {
    graph = `gradients=s=1280x720:r=30:c0=${palette.bg0}:c1=${palette.bg1}:x0=0:y0=720:x1=1280:y1=0:type=linear[bg];[0:a]showwaves=s=1280x540:mode=cline:colors=${palette.first}|${palette.second}:r=30[wave];[wave]colorkey=0x000000:0.08:0.10[fg];[bg][fg]overlay=0:90:format=auto,format=rgba[base];[1:v]format=rgba[text];[base][text]overlay=0:0:format=auto:shortest=1,format=yuv420p[out]`;
  } else {
    const spectrumColor = paletteName === 'ocean' ? 'cool' : paletteName === 'sunset' ? 'fiery' : paletteName === 'violet' ? 'nebulae' : 'viridis';
    graph = `gradients=s=1280x720:r=30:c0=${palette.bg0}:c1=${palette.bg1}:x0=0:y0=720:x1=1280:y1=0:type=linear[bg];[0:a]showspectrum=s=1280x720:mode=combined:color=${spectrumColor}:scale=log:fscale=log:slide=scroll:legend=0:fps=30,eq=brightness=-0.04:saturation=1.30,format=rgba,colorkey=0x000000:0.08:0.10[fg];[bg][fg]overlay=0:0:format=auto:shortest=1,format=rgba[base];[1:v]format=rgba[text];[base][text]overlay=0:0:format=auto:shortest=1,format=yuv420p[out]`;
  }

  await runFfmpeg([
    '-i', audioPath,
    '-loop', '1', '-framerate', '30', '-i', overlayPath,
    '-filter_complex_threads', '2',
    '-filter_complex', graph,
    '-map', '[out]', '-map', '0:a:0',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-r', '30', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', '-shortest', outputPath,
  ], { onProgress, progressRange: [5, 98] });
  onProgress(100);
  return outputPath;
}

export async function createDemoAudio(jobDir) {
  const output = path.join(jobDir, 'audio.mp3');
  await runFfmpeg([
    '-f', 'lavfi', '-i', 'aevalsrc=0.14*sin(2*PI*220*t)+0.09*sin(2*PI*277.18*t)+0.07*sin(2*PI*329.63*t):s=44100:d=12',
    '-af', 'tremolo=f=3.5:d=0.45,aecho=0.8:0.5:90:0.22,afade=t=in:d=1,afade=t=out:st=10:d=2',
    '-c:a', 'libmp3lame', '-b:a', '192k', output,
  ]);
  return output;
}
