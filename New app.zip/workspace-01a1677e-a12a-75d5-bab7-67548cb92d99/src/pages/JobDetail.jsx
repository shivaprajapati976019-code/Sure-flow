import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, CheckCircle2, ChevronDown, CircleAlert, Clock3, Download, ExternalLink, FileAudio, FileVideo, LoaderCircle, RefreshCw, Rocket, Sparkles } from 'lucide-react';
import { Youtube } from '../components/YoutubeIcon.jsx';
import { api, mediaUrl, openExternal } from '../api.js';
import { ACTIVE_STATUSES } from '../data.js';
import { classNames, formatDate } from '../utils.js';
import Visualizer from '../components/Visualizer.jsx';
import { InlineNotice, Spinner, StatusPill } from '../components/UI.jsx';

export default function JobDetail({ job, navigate, notify, refresh }) {
  const [busy, setBusy] = useState('');
  const [openSection, setOpenSection] = useState('metadata');
  if (!job) return <div className="page"><div className="empty-state"><h3>Release nahi mili</h3><button className="btn btn-ghost" onClick={() => navigate('/library')}>Library kholein</button></div></div>;
  const active = ACTIVE_STATUSES.includes(job.status);

  async function retry() {
    setBusy('retry');
    try { await api(`/api/jobs/${job.id}/retry`, { method: 'POST' }); await refresh(); notify('Workflow wahi se resume ho raha hai; saved files reuse hongi.', 'success'); }
    catch (error) { notify(error.message, 'error'); } finally { setBusy(''); }
  }
  async function publish() {
    setBusy('publish');
    try { await api(`/api/jobs/${job.id}/publish`, { method: 'POST', body: {} }); await refresh(); notify('YouTube upload complete.', 'success'); }
    catch (error) { notify(error.message, 'error'); await refresh(); } finally { setBusy(''); }
  }

  return <div className="page job-detail-page">
    <div className="job-detail-top"><button className="back-link" onClick={() => navigate('/library')}><ArrowLeft size={17} />Release library</button><div className="job-detail-actions">{job.videoUrl && <a className="btn btn-ghost btn-small" href={mediaUrl(job.videoUrl)} download={`${job.title || 'surflow-release'}.mp4`}><Download size={16} />MP4 download</a>}{job.youtube?.url && <button className="btn btn-primary btn-small" onClick={() => openExternal(job.youtube.url)}>YouTube par dekhein<ExternalLink size={16} /></button>}</div></div>

    <div className="job-title-row"><div><div className="job-title-badges"><StatusPill status={job.status} />{job.demo && <span className="demo-tag">LOCAL DEMO</span>}</div><h1>{job.title || job.input?.topic}</h1><p>{job.input?.genre} <span>•</span> {job.input?.language} <span>•</span> {formatDate(job.createdAt, true)}</p></div>{['ready', 'action_required', 'failed'].includes(job.status) && !job.demo && job.videoUrl && <button className="btn btn-primary" onClick={publish} disabled={Boolean(busy)}>{busy === 'publish' ? <Spinner /> : <Rocket size={17} />}Publish to YouTube</button>}</div>

    {job.demo && <InlineNotice title="Yeh free local demo hai">Isme koi AI service call, paid credit ya YouTube upload use nahi hua. 12-second original instrumental se actual MP4 renderer test hua hai.</InlineNotice>}
    {job.error && <InlineNotice tone="warning" title={job.action === 'connect_youtube' ? 'YouTube connection chahiye' : 'Workflow ko aapki action chahiye'} action={<button className="btn btn-warning btn-small" onClick={job.action === 'connect_youtube' ? () => navigate('/settings') : retry}>{job.action === 'connect_youtube' ? 'Connect karein' : 'Retry'}<ArrowRight size={15} /></button>}>{job.error.message}</InlineNotice>}

    <div className="job-detail-layout">
      <div className="job-detail-main">
        <div className="video-stage">
          {job.videoUrl ? <video src={mediaUrl(job.videoUrl)} controls playsInline preload="metadata" className="final-video" /> : <Visualizer template={job.options?.visualTemplate} paletteName={job.options?.visualPalette} title={job.creative?.songTitle || job.title} artist="Original release" audioUrl={job.audioUrl ? mediaUrl(job.audioUrl) : ''} />}
          {active && <div className="render-overlay"><div className="render-spinner"><LoaderCircle size={28} className="spin" /></div><strong>{job.currentStage === 'music' ? 'AI music ban raha hai' : job.currentStage === 'video' ? 'HD video render ho raha hai' : job.currentStage === 'publish' ? 'YouTube par upload ho raha hai' : 'AI apna kaam kar raha hai'}</strong><span>{job.progress || 0}% complete</span></div>}
        </div>

        {(active || job.status === 'action_required' || job.status === 'failed') && <div className="overall-progress"><div><span>Overall progress</span><strong>{job.progress || 0}%</strong></div><div className="progress-track"><i style={{ width: `${job.progress || 0}%` }} /></div></div>}

        <div className="release-accordion">
          <Accordion id="metadata" title="YouTube metadata" icon={<Youtube size={18} />} open={openSection} setOpen={setOpenSection}>
            {job.metadata ? <div className="metadata-view"><div><label>Title</label><p>{job.metadata.title}</p></div><div><label>Description</label><p className="pre-wrap">{job.metadata.description}</p></div><div><label>Tags</label><div className="tag-list">{job.metadata.tags?.map((tag) => <span key={tag}>{tag}</span>)}</div></div></div> : <p className="muted">Metadata abhi banega.</p>}
          </Accordion>
          <Accordion id="lyrics" title="Lyrics & music style" icon={<Sparkles size={18} />} open={openSection} setOpen={setOpenSection}>
            {job.creative ? <div className="metadata-view"><div><label>Lyrics</label><p className="pre-wrap lyrics-view">{job.creative.lyrics || 'Instrumental'}</p></div><div><label>Music style</label><p className="pre-wrap">{job.creative.style}</p></div></div> : <p className="muted">Lyrics abhi banengi.</p>}
          </Accordion>
          <Accordion id="files" title="Generated files & details" icon={<FileVideo size={18} />} open={openSection} setOpen={setOpenSection}>
            <div className="file-list">{job.audioUrl && <a href={mediaUrl(job.audioUrl)} download><FileAudio size={19} /><span><strong>Song audio</strong><small>Original generated/imported audio</small></span><Download size={16} /></a>}{job.videoUrl && <a href={mediaUrl(job.videoUrl)} download><FileVideo size={19} /><span><strong>YouTube-ready MP4</strong><small>1280×720 • H.264 + AAC</small></span><Download size={16} /></a>}{job.music?.taskId && <div className="file-detail"><span>MusicGPT task</span><code>{job.music.taskId}</code></div>}{job.youtube?.videoId && <div className="file-detail"><span>YouTube video ID</span><code>{job.youtube.videoId}</code></div>}</div>
          </Accordion>
        </div>
      </div>

      <aside className="job-detail-aside">
        <div className="side-card pipeline-status-card"><span className="eyebrow">RELEASE PIPELINE</span><h3>{job.status === 'published' ? 'Release live hai' : job.status === 'scheduled' ? 'Release scheduled hai' : job.status === 'ready' ? 'Video ready hai' : 'Workflow status'}</h3><div className="vertical-steps">{job.stages?.map((stage, index) => <div className={classNames('vertical-step', stage.status)} key={stage.id}><span className="vertical-step-icon">{stage.status === 'completed' ? <Check size={15} /> : stage.status === 'active' ? <LoaderCircle size={16} className="spin" /> : stage.status === 'error' ? <CircleAlert size={15} /> : stage.status === 'skipped' ? <Check size={14} /> : <Clock3 size={15} />}</span><div><strong>{stage.label}</strong><small>{stage.status === 'completed' ? 'Complete' : stage.status === 'active' ? 'In progress…' : stage.status === 'error' ? 'Action required' : stage.status === 'skipped' ? 'Skipped / review only' : 'Waiting'}</small></div>{index < job.stages.length - 1 && <i />}</div>)}</div></div>
        {job.youtube && <div className="side-card youtube-result"><span className="youtube-icon"><Youtube size={22} /></span><h3>{job.status === 'scheduled' ? 'YouTube par scheduled' : 'YouTube upload complete'}</h3>{job.youtube.publishAt && <p>Publish time: {formatDate(job.youtube.publishAt, true)}</p>}<button className="btn btn-ghost btn-full" onClick={() => openExternal(job.youtube.url)}>Video kholein<ExternalLink size={15} /></button></div>}
        {job.status === 'ready' && !job.demo && <div className="side-card ready-card"><CheckCircle2 size={25} /><h3>Master ready hai</h3><p>Download karke review karein ya abhi YouTube par publish karein.</p>{!job.options.autoPublish && <button className="btn btn-primary btn-full" onClick={publish} disabled={Boolean(busy)}>{busy === 'publish' ? <Spinner /> : <Youtube size={17} />}Publish now</button>}</div>}
        {job.status === 'failed' && <button className="btn btn-primary btn-full" onClick={retry} disabled={Boolean(busy)}>{busy === 'retry' ? <Spinner /> : <RefreshCw size={17} />}Workflow retry karein</button>}
        <div className="side-card activity-log"><span className="eyebrow">ACTIVITY</span>{[...(job.logs || [])].reverse().slice(0, 6).map((entry, index) => <div key={`${entry.at}-${index}`}><i /><p>{entry.message}<small>{formatDate(entry.at, true)}</small></p></div>)}</div>
      </aside>
    </div>
  </div>;
}

function Accordion({ id, title, icon, open, setOpen, children }) {
  const expanded = open === id;
  return <section className={classNames('accordion', expanded && 'open')}><button onClick={() => setOpen(expanded ? '' : id)}><span>{icon}{title}</span><ChevronDown size={18} /></button>{expanded && <div className="accordion-content">{children}</div>}</section>;
}
