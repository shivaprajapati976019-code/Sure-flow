import fs from 'node:fs';
import { getSecret, setSecret, deleteSecret } from './secrets.js';
import { getYoutube, updateYoutube } from './store.js';
import { YOUTUBE_CALLBACK } from './config.js';
import { AppError } from './errors.js';
import { asString, fetchChecked, sleep } from './utils.js';

const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPES = [
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/youtube.readonly',
];

function googleConfig() {
  const clientId = process.env.GOOGLE_CLIENT_ID || getSecret('googleClientId');
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET || getSecret('googleClientSecret');
  if (!clientId || !clientSecret) {
    throw new AppError('Google Cloud OAuth Client ID aur Secret Settings mein add karein.', 412, 'YOUTUBE_OAUTH_CONFIG_REQUIRED', { redirectUri: YOUTUBE_CALLBACK });
  }
  return { clientId, clientSecret };
}

export function youtubeAuthUrl(state) {
  const { clientId } = googleConfig();
  const query = new URLSearchParams({
    client_id: clientId,
    redirect_uri: YOUTUBE_CALLBACK,
    response_type: 'code',
    scope: SCOPES.join(' '),
    access_type: 'offline',
    prompt: 'consent',
    include_granted_scopes: 'true',
    state,
  });
  return `${AUTH_URL}?${query}`;
}

export async function completeYoutubeAuth(code) {
  const { clientId, clientSecret } = googleConfig();
  const tokens = await fetchChecked(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: YOUTUBE_CALLBACK,
      grant_type: 'authorization_code',
    }),
  }, 'Google OAuth');
  if (tokens.refresh_token) setSecret('googleRefreshToken', tokens.refresh_token);
  if (tokens.access_token) setSecret('googleAccessToken', tokens.access_token);
  if (!tokens.refresh_token && !getSecret('googleRefreshToken')) {
    throw new AppError('Google ne refresh token nahi diya. Connection hata kar prompt=consent ke saath dobara connect karein.', 400, 'YOUTUBE_REFRESH_TOKEN_MISSING');
  }
  updateYoutube({ connected: true, connectedAt: new Date().toISOString(), tokenExpiry: Date.now() + (Number(tokens.expires_in || 3600) * 1000) });
  try {
    const accessToken = await validAccessToken();
    const data = await fetchChecked('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', {
      headers: { Authorization: `Bearer ${accessToken}` },
    }, 'YouTube channel');
    const channel = data?.items?.[0];
    if (channel) updateYoutube({ channelId: channel.id, channelTitle: channel.snippet?.title || '' });
  } catch {
    // Upload permission is already stored; channel title is cosmetic and can be retried later.
  }
  return getYoutube();
}

export async function validAccessToken() {
  const current = getYoutube();
  const cached = getSecret('googleAccessToken');
  if (cached && current.tokenExpiry > Date.now() + 60_000) return cached;
  const refreshToken = getSecret('googleRefreshToken');
  if (!refreshToken) throw new AppError('YouTube account connected nahi hai.', 412, 'YOUTUBE_NOT_CONNECTED');
  const { clientId, clientSecret } = googleConfig();
  const tokens = await fetchChecked(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  }, 'Google token refresh');
  setSecret('googleAccessToken', tokens.access_token);
  updateYoutube({ tokenExpiry: Date.now() + (Number(tokens.expires_in || 3600) * 1000), connected: true });
  return tokens.access_token;
}

export function disconnectYoutube() {
  deleteSecret('googleRefreshToken');
  deleteSecret('googleAccessToken');
  updateYoutube({ connected: false, channelId: '', channelTitle: '', connectedAt: null, tokenExpiry: 0 });
}

async function uploadChunk(uploadUrl, buffer, start, end, total, attempt = 0) {
  const response = await fetch(uploadUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': 'video/mp4',
      'Content-Length': String(buffer.length),
      'Content-Range': `bytes ${start}-${end}/${total}`,
    },
    body: buffer,
    signal: AbortSignal.timeout(120_000),
  });
  if (response.status === 308) return { done: false, range: response.headers.get('range') };
  const text = await response.text();
  let body;
  try { body = text ? JSON.parse(text) : {}; } catch { body = {}; }
  if ([429, 500, 502, 503, 504].includes(response.status) && attempt < 4) {
    await sleep((attempt + 1) * 2500);
    return uploadChunk(uploadUrl, buffer, start, end, total, attempt + 1);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.error || text || `HTTP ${response.status}`;
    throw new AppError(`YouTube upload error: ${String(message).slice(0, 500)}`, response.status === 401 ? 412 : 400, 'YOUTUBE_UPLOAD_FAILED');
  }
  return { done: true, body };
}

export async function uploadToYoutube({ videoPath, metadata, privacy, scheduleAt, madeForKids, containsSyntheticMedia, onProgress = () => {} }) {
  if (!fs.existsSync(videoPath)) throw new AppError('Upload ke liye video file nahi mili.', 412, 'VIDEO_MISSING');
  const accessToken = await validAccessToken();
  const size = fs.statSync(videoPath).size;
  const scheduled = scheduleAt ? new Date(scheduleAt) : null;
  if (scheduled && (Number.isNaN(scheduled.getTime()) || scheduled.getTime() <= Date.now() + 30_000)) {
    throw new AppError('Schedule time kam se kam 1 minute future mein hona chahiye.', 400, 'INVALID_SCHEDULE');
  }
  const status = {
    privacyStatus: scheduled ? 'private' : privacy,
    selfDeclaredMadeForKids: Boolean(madeForKids),
    containsSyntheticMedia: Boolean(containsSyntheticMedia),
  };
  if (scheduled) status.publishAt = scheduled.toISOString();
  const payload = {
    snippet: {
      title: asString(metadata.title, 100).replace(/[<>]/g, ''),
      description: asString(metadata.description, 5000).replace(/[<>]/g, ''),
      tags: Array.isArray(metadata.tags) ? metadata.tags.slice(0, 15) : [],
      categoryId: '10',
    },
    status,
  };
  const initiate = await fetch(`https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet%2Cstatus`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json; charset=UTF-8',
      'X-Upload-Content-Type': 'video/mp4',
      'X-Upload-Content-Length': String(size),
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60_000),
  });
  if (!initiate.ok) {
    const body = await initiate.text();
    let message = body;
    try { message = JSON.parse(body)?.error?.message || body; } catch { /* text is already useful */ }
    throw new AppError(`YouTube upload start nahi hua: ${String(message).slice(0, 500)}`, initiate.status === 401 ? 412 : 400, 'YOUTUBE_UPLOAD_INIT_FAILED');
  }
  const uploadUrl = initiate.headers.get('location');
  if (!uploadUrl) throw new AppError('YouTube ne resumable upload URL nahi diya.', 502, 'YOUTUBE_UPLOAD_URL_MISSING');

  const chunkSize = 8 * 1024 * 1024;
  const handle = await fs.promises.open(videoPath, 'r');
  let offset = 0;
  let result;
  try {
    while (offset < size) {
      const length = Math.min(chunkSize, size - offset);
      const buffer = Buffer.allocUnsafe(length);
      await handle.read(buffer, 0, length, offset);
      const response = await uploadChunk(uploadUrl, buffer, offset, offset + length - 1, size);
      offset += length;
      onProgress(Math.round((offset / size) * 100));
      if (response.done) { result = response.body; break; }
      if (response.range) {
        const match = response.range.match(/bytes=0-(\d+)/);
        if (match) offset = Number(match[1]) + 1;
      }
    }
  } finally {
    await handle.close();
  }
  const videoId = result?.id;
  if (!videoId) throw new AppError('Upload complete hua, lekin YouTube video ID response mein nahi mili.', 502, 'YOUTUBE_VIDEO_ID_MISSING');
  return { videoId, url: `https://youtu.be/${videoId}`, publishAt: status.publishAt || null, privacyStatus: status.privacyStatus };
}
