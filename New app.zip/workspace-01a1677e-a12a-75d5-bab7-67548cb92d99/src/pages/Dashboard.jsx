import React, { useState } from 'react';
import { ArrowRight, AudioLines, CalendarClock, CheckCircle2, Library, Plus, Settings2, Sparkles, UploadCloud, WandSparkles } from 'lucide-react';
import { Youtube } from '../components/YoutubeIcon.jsx';
import { api } from '../api.js';
import { ACTIVE_STATUSES } from '../data.js';
import { EmptyState, JobCard, SectionTitle, SetupItem, Toggle } from '../components/UI.jsx';
import { formatDate } from '../utils.js';

export default function Dashboard({ data, refresh, navigate, notify, onDemo, demoBusy }) {
  const [toggleBusy, setToggleBusy] = useState(false);
  const jobs = data.jobs || [];
  const active = jobs.filter((job) => ACTIVE_STATUSES.includes(job.status));
  const published = jobs.filter((job) => job.status === 'published');
  const scheduled = jobs.filter((job) => job.status === 'scheduled');
  const textKey = data.settings.textProvider === 'openai' ? data.secrets.openaiApiKey : data.secrets.geminiApiKey;
  const setupDone = [textKey, data.secrets.musicgptApiKey, data.youtube.connected].filter(Boolean).length;

  async function toggleAutomation(value) {
    setToggleBusy(true);
    try {
      await api('/api/settings', { method: 'PUT', body: { settings: { autoPublish: value } } });
      await refresh();
      notify(value ? 'Full-auto publishing on hai.' : 'Auto-publish off hai; videos review ke liye ready honge.', 'success');
    } catch (error) { notify(error.message, 'error'); } finally { setToggleBusy(false); }
  }

  return <div className="page dashboard-page">
    <div className="page-heading dashboard-heading">
      <div><span className="eyebrow">YOUR MUSIC STUDIO</span><h1>Namaste, creator <span className="wave-emoji">👋</span></h1><p>Aaj kya naya release karna hai?</p></div>
      <button className="btn btn-primary desktop-create" onClick={() => navigate('/create')}><Plus size={18} />Naya song</button>
    </div>

    <section className="hero-card">
      <div className="hero-noise" /><div className="hero-orb hero-orb-one" /><div className="hero-orb hero-orb-two" />
      <div className="hero-content">
        <div className="hero-kicker"><WandSparkles size={15} /> IDEA SE YOUTUBE TAK</div>
        <h2>Aapka agla gaana,<br /><span>autopilot par.</span></h2>
        <p>Lyrics, music, visualizer, metadata aur upload—ek connected workflow mein.</p>
        <div className="hero-actions"><button className="btn btn-primary btn-large" onClick={() => navigate('/create')}>Release shuru karein<ArrowRight size={18} /></button><button className="btn btn-dark btn-large" onClick={onDemo} disabled={demoBusy}>{demoBusy ? 'Demo ban raha hai…' : 'Free demo dekho'}<Sparkles size={17} /></button></div>
      </div>
      <div className="hero-pipeline" aria-label="Automation pipeline">
        {[['01', 'Write', 'Lyrics + style'], ['02', 'Create', 'AI music'], ['03', 'Render', 'HD video'], ['04', 'Release', 'YouTube']].map(([number, title, subtitle], index) => <div className="pipeline-step" key={number}><span className="pipeline-number">{number}</span><div><strong>{title}</strong><small>{subtitle}</small></div>{index < 3 && <i />}</div>)}
      </div>
    </section>

    {setupDone < 3 && <section className="setup-banner">
      <div className="setup-banner-icon"><Settings2 size={22} /></div>
      <div><strong>Full automation ke liye {3 - setupDone} connection{3 - setupDone === 1 ? '' : 's'} baaki</strong><p>Website password nahi—sirf official API keys aur secure Google OAuth.</p></div>
      <button className="btn btn-ghost btn-small" onClick={() => navigate('/settings')}>Setup karein<ArrowRight size={16} /></button>
    </section>}

    <div className="stats-grid">
      <div className="stat-card"><span className="stat-icon lime"><AudioLines size={19} /></span><div><strong>{active.length}</strong><small>Abhi ban rahe</small></div><span className="stat-caption">LIVE</span></div>
      <div className="stat-card"><span className="stat-icon violet"><UploadCloud size={19} /></span><div><strong>{published.length}</strong><small>Published releases</small></div></div>
      <div className="stat-card"><span className="stat-icon orange"><CalendarClock size={19} /></span><div><strong>{scheduled.length}</strong><small>Scheduled</small></div></div>
      <div className="stat-card"><span className="stat-icon blue"><Library size={19} /></span><div><strong>{jobs.length}</strong><small>Total projects</small></div></div>
    </div>

    <div className="dashboard-columns">
      <section className="dashboard-main">
        <SectionTitle title="Recent releases" description="Aapke latest projects aur unka live status" action={jobs.length > 0 && <button className="text-button" onClick={() => navigate('/library')}>Sab dekhein<ArrowRight size={15} /></button>} />
        <div className="job-list">
          {jobs.length === 0 ? <EmptyState onCreate={() => navigate('/create')} onDemo={onDemo} /> : jobs.slice(0, 4).map((job) => <JobCard key={job.id} job={job} onClick={() => navigate(`/jobs/${job.id}`)} />)}
        </div>
      </section>

      <aside className="dashboard-aside">
        <div className="side-card automation-card">
          <div className="side-card-heading"><span className="stat-icon lime"><Sparkles size={18} /></span><div><h3>Automation</h3><p>Release preferences</p></div></div>
          <Toggle checked={data.settings.autoPublish} onChange={toggleAutomation} disabled={toggleBusy} label="Full-auto publish" description="Video ready hote hi YouTube upload" />
          <div className="automation-meta"><span>Default visibility</span><strong>{data.settings.privacy}</strong></div>
          <div className="automation-meta"><span>Daily safety limit</span><strong>{data.settings.dailyLimit} uploads</strong></div>
        </div>

        {scheduled.length > 0 && <div className="side-card next-release"><span className="eyebrow">NEXT RELEASE</span><CalendarClock size={25} /><h3>{scheduled[0].title}</h3><p>{formatDate(scheduled[0].youtube?.publishAt, true)}</p><button className="text-button" onClick={() => navigate(`/jobs/${scheduled[0].id}`)}>Release kholein<ArrowRight size={15} /></button></div>}

        <div className="side-card setup-card">
          <div className="side-card-heading"><div><h3>Quick setup</h3><p>{setupDone}/3 connections ready</p></div><span className="setup-score">{Math.round(setupDone / 3 * 100)}%</span></div>
          <div className="setup-progress"><i style={{ width: `${setupDone / 3 * 100}%` }} /></div>
          <SetupItem done={textKey} title="AI writer" description={textKey ? `${data.settings.textProvider} connected` : 'Gemini ya OpenAI key'} onClick={() => navigate('/settings')} />
          <SetupItem done={data.secrets.musicgptApiKey} title="Music generator" description={data.secrets.musicgptApiKey ? 'MusicGPT API ready' : 'API key ya audio import'} onClick={() => navigate('/settings')} />
          <SetupItem done={data.youtube.connected} title="YouTube channel" description={data.youtube.connected ? data.youtube.channelTitle || 'Connected' : 'Secure Google OAuth'} onClick={() => navigate('/settings')} />
        </div>

        {data.youtube.connected && <div className="connected-channel"><span className="youtube-icon"><Youtube size={20} /></span><div><small>CONNECTED CHANNEL</small><strong>{data.youtube.channelTitle || 'Your YouTube channel'}</strong></div><CheckCircle2 size={18} /></div>}
      </aside>
    </div>
  </div>;
}
